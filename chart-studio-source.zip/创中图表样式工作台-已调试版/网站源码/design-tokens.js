// Figma sWhGJbvGtUe0D0JIia4du5 · 354:524 (light) / 354:655 (dark)
const DESIGN_TOKENS = {
  "light": {
    "MapText03A": "#36393f",
    "MapCriticalTip": "#d95350",
    "MapUIFrame10A": "#f5f7fa",
    "MapText02A": "#191b1f",
    "MapUIFrame99A": "#ffffff",
    "MapUIFrame09B": "#e8e9ed",
    "MapUIFrame09A": "#e8eaed",
    "MapUIFrame08A": "#c3c7cf",
    "MapText06A": "#9196a1",
    "MapCriticalHot": "#d95350",
    "MapPositiveLike": "#f05159",
    "MapPositiveDonate": "#f05159",
    "MapPositiveAlt": "#ff65c6",
    "MapLiveBrand": "#ff4b6f",
    "MapUIAccentA": "#fa7991",
    "MapHighlight": "#f77932",
    "MapCommerce": "#ff501a",
    "MapCommerceAlt": "#ff7d55",
    "MapTime": "#f77932",
    "MapFavorite": "#fa9d14",
    "MapUIAccentB": "#fcd60d",
    "MapPass": "#67c23a",
    "MapUIAccentC": "#16b89b",
    "MapBrand": "#1772f6",
    "MapBrandAlt": "#05aaf4",
    "MapBrandLight": "#acd2ff",
    "MapVIPKnowledge": "#3952a1",
    "MapVIPKnowledgeAlt": "#3952a1",
    "MapVIPKnowledgeLight": "#f4f7ff",
    "MapVIPKnowledgeLightAlt": "#f4f7ff",
    "MapSVIPBrand": "#384264",
    "MapSVIPBrandAlt": "#142456",
    "MapInfo": "#1772f6",
    "MapInfoSub": "#8590a6",
    "MapLink": "#084289",
    "MapAI": "#574cf8",
    "MapEvent": "#6a5ff3",
    "MapReward": "#a5542f",
    "MapVIPBrand": "#ce994f",
    "MapVIPUIFrame": "#f8e2c4",
    "MapVIPUIFrameAlt": "#f3bb6c",
    "MapVIPText01": "#754e19",
    "MapVIPText02": "#754e19",
    "MapUIFrame01A": "#000000",
    "MapText04A": "#545962",
    "MapText05A": "#81858f",
    "MapText07A": "#adb1b7",
    "MapText99B": "#ffffff",
    "MapUIFrame07A": "#adb1b7",
    "MapUIFrame08B": "#c3c7cf",
    "MapUIFrame10C": "#f5f7fa",
    "MapUIFrame99B": "#ffffff",
    "MapUIFrame99C": "#ffffff"
  },
  "dark": {
    "MapText03A": "#c3c7cf",
    "MapCriticalTip": "#d95350",
    "MapUIFrame10A": "#222429",
    "MapText02A": "#ffffff",
    "MapUIFrame99A": "#191b1f",
    "MapUIFrame09B": "#152029",
    "MapUIFrame09A": "#272a30",
    "MapUIFrame08A": "#272a30",
    "MapText06A": "#9196a1",
    "MapCriticalHot": "#d95350",
    "MapPositiveLike": "#f05159",
    "MapPositiveDonate": "#f05159",
    "MapPositiveAlt": "#ff65c6",
    "MapLiveBrand": "#ff5066",
    "MapUIAccentA": "#fa7991",
    "MapHighlight": "#f77932",
    "MapCommerce": "#ff7744",
    "MapCommerceAlt": "#ffa280",
    "MapTime": "#f77932",
    "MapFavorite": "#fa9d14",
    "MapUIAccentB": "#fcd60d",
    "MapPass": "#92cb76",
    "MapUIAccentC": "#16b89b",
    "MapBrand": "#558eff",
    "MapBrandAlt": "#55b5ff",
    "MapBrandLight": "#1772f6",
    "MapVIPKnowledge": "#b2c4ff",
    "MapVIPKnowledgeAlt": "#3952a1",
    "MapVIPKnowledgeLight": "#1f2639",
    "MapVIPKnowledgeLightAlt": "#f4f7ff",
    "MapSVIPBrand": "#384264",
    "MapSVIPBrandAlt": "#142456",
    "MapInfo": "#558eff",
    "MapInfoSub": "#606a80",
    "MapLink": "#5171b0",
    "MapAI": "#6a5ff3",
    "MapEvent": "#6a5ff3",
    "MapReward": "#d28262",
    "MapVIPBrand": "#cc9850",
    "MapVIPUIFrame": "#f8e2c4",
    "MapVIPUIFrameAlt": "#f3bb6c",
    "MapVIPText01": "#754e19",
    "MapVIPText02": "#f8e2c4",
    "MapUIFrame01A": "#000000",
    "MapText04A": "#c3c7cf",
    "MapText05A": "#9196a1",
    "MapText07A": "#5a5e66",
    "MapText99B": "#ffffff",
    "MapUIFrame07A": "#5a5e66",
    "MapUIFrame08B": "#222429",
    "MapUIFrame10C": "#000000",
    "MapUIFrame99B": "#ffffff",
    "MapUIFrame99C": "#272a30"
  }
};
const TOKEN_META = {
  "MapText03A": {
    "label": "Text/03A 正文 MapText03A",
    "group": "Text"
  },
  "MapCriticalTip": {
    "label": "Red/提示红 MapCriticalTip",
    "group": "Red"
  },
  "MapUIFrame10A": {
    "label": "Frame/10A 组件常用灰 MapUIFrame10A",
    "group": "Frame"
  },
  "MapText02A": {
    "label": "Text/02A 主标题 MapText02A",
    "group": "Text"
  },
  "MapUIFrame99A": {
    "label": "Frame/99A 页面白背景 MapUIFrame99A",
    "group": "Frame"
  },
  "MapUIFrame09B": {
    "label": "Frame/09B 浅色分割线2 MapUIFrame09B",
    "group": "Frame"
  },
  "MapUIFrame09A": {
    "label": "Frame/09A 浅色分割线1 MapUIFrame09A",
    "group": "Frame"
  },
  "MapUIFrame08A": {
    "label": "Frame/08A 深色分割线1 MapUIFrame08A",
    "group": "Frame"
  },
  "MapText06A": {
    "label": "Text/06A 辅助信息 MapText06A",
    "group": "Text"
  },
  "MapCriticalHot": {
    "label": "Red/关键红 MapCriticalHot（隐藏）",
    "group": "Red"
  },
  "MapPositiveLike": {
    "label": "Pink/互动粉 MapPositiveLike",
    "group": "Pink"
  },
  "MapPositiveDonate": {
    "label": "Pink/赞赏粉 MapPositiveDonate（隐藏）",
    "group": "Pink"
  },
  "MapPositiveAlt": {
    "label": "Pink/赞赏粉扩展 MapPositiveAlt（隐藏）",
    "group": "Pink"
  },
  "MapLiveBrand": {
    "label": "Pink/直播粉 MapLiveBrand",
    "group": "Pink"
  },
  "MapUIAccentA": {
    "label": "Pink/强调粉 MapUIAccentA",
    "group": "Pink"
  },
  "MapHighlight": {
    "label": "Orange/高亮橘 MapHighlight",
    "group": "Orange"
  },
  "MapCommerce": {
    "label": "Orange/商业橘 MapCommerce",
    "group": "Orange"
  },
  "MapCommerceAlt": {
    "label": "Orange/商业橘扩展 MapCommerceAlt",
    "group": "Orange"
  },
  "MapTime": {
    "label": "Orange/时效橘 MapTime（隐藏）",
    "group": "Orange"
  },
  "MapFavorite": {
    "label": "Tangerine/收藏桔 MapFavorite",
    "group": "Tangerine"
  },
  "MapUIAccentB": {
    "label": "Yellow/强调黄 MapUIAccentB",
    "group": "Yellow"
  },
  "MapPass": {
    "label": "Green/通过绿 MapPass",
    "group": "Green"
  },
  "MapUIAccentC": {
    "label": "Green/强调绿 MapUIAccentC",
    "group": "Green"
  },
  "MapBrand": {
    "label": "Blue/品牌蓝 MapBrand",
    "group": "Blue"
  },
  "MapBrandAlt": {
    "label": "Blue/品牌蓝扩展 MapBrandAlt（隐藏）",
    "group": "Blue"
  },
  "MapBrandLight": {
    "label": "Blue/品牌蓝浅色 MapBrandLight",
    "group": "Blue"
  },
  "MapVIPKnowledge": {
    "label": "Blue/知识会员 MapVIPKnowledge",
    "group": "Blue"
  },
  "MapVIPKnowledgeAlt": {
    "label": "Blue/知识会员单色 MapVIPKnowledgeAlt",
    "group": "Blue"
  },
  "MapVIPKnowledgeLight": {
    "label": "Blue/知识会员浅色 MapVIPKnowledgeLight",
    "group": "Blue"
  },
  "MapVIPKnowledgeLightAlt": {
    "label": "Blue/知识会员浅色单色 MapVIPKnowledgeLightAlt",
    "group": "Blue"
  },
  "MapSVIPBrand": {
    "label": "Blue/超级会员品牌蓝 MapSVIPBrand",
    "group": "Blue"
  },
  "MapSVIPBrandAlt": {
    "label": "Blue/超级会员蓝扩展 MapSVIPBrandAlt",
    "group": "Blue"
  },
  "MapInfo": {
    "label": "Blue/信息蓝 MapInfo（隐藏）",
    "group": "Blue"
  },
  "MapInfoSub": {
    "label": "Blue/次级信息蓝 MapInfoSub",
    "group": "Blue"
  },
  "MapLink": {
    "label": "Blue/链接蓝 MapLink",
    "group": "Blue"
  },
  "MapAI": {
    "label": "Purple/AI 紫 MapAI",
    "group": "Purple"
  },
  "MapEvent": {
    "label": "Purple/活动紫 MapEvent",
    "group": "Purple"
  },
  "MapReward": {
    "label": "Brown/正向金 MapReward",
    "group": "Brown"
  },
  "MapVIPBrand": {
    "label": "Golden/会员品牌金 MapVIPBrand",
    "group": "Golden"
  },
  "MapVIPUIFrame": {
    "label": "Golden/会员 UI 金 MapVIPUIFrame",
    "group": "Golden"
  },
  "MapVIPUIFrameAlt": {
    "label": "Golden/会员 UI 金扩展 MapVIPUIFrameAlt",
    "group": "Golden"
  },
  "MapVIPText01": {
    "label": "Golden/会员文本金01 MapVIPText01",
    "group": "Golden"
  },
  "MapVIPText02": {
    "label": "Golden/会员文本金02 MapVIPText02",
    "group": "Golden"
  },
  "MapUIFrame01A": {
    "label": "Frame/01A 遮罩或投影 MapUIFrame01A",
    "group": "Frame"
  },
  "MapText04A": {
    "label": "Text/04A 次级文本 MapText04A",
    "group": "Text"
  },
  "MapText05A": {
    "label": "Text/05A 过渡文本 MapText05A",
    "group": "Text"
  },
  "MapText07A": {
    "label": "Text/07A 预置或失效 MapText07A",
    "group": "Text"
  },
  "MapText99B": {
    "label": "Text/99B 白色文本 MapText99B",
    "group": "Text"
  },
  "MapUIFrame07A": {
    "label": "Frame/07A 失效禁用 MapUIFrame07A",
    "group": "Frame"
  },
  "MapUIFrame08B": {
    "label": "Frame/08B 深色分割线2 MapUIFrame08B",
    "group": "Frame"
  },
  "MapUIFrame10C": {
    "label": "Frame/10C 页面灰背景 MapUIFrame10C",
    "group": "Frame"
  },
  "MapUIFrame99B": {
    "label": "Frame/99B 始终白色 MapUIFrame99B",
    "group": "Frame"
  },
  "MapUIFrame99C": {
    "label": "Frame/99C 悬浮控件白 MapUIFrame99C",
    "group": "Frame"
  }
};
const DEFAULT_TOKEN_BINDINGS={regionBarColor:'MapBrand',regionRankNameColor:'MapText06A',regionRankValueColor:'MapText06A',regionTrackColor:'MapUIFrame10A',tooltipNameColor:'MapText03A',mapStrokeColor:'MapUIFrame99A',mapHoverStrokeColor:'MapBrand',mapBoundaryColor:'MapText06A',series0:'MapBrand',series1:'MapUIAccentC',series2:'MapPass',series3:'MapUIAccentB',series4:'MapHighlight',series5:'MapCriticalTip',series6:'MapPositiveAlt',series7:'MapAI',bg:'MapUIFrame99A',text:'MapText06A',gridColor:'MapUIFrame09A',fillTop:'MapBrand',fillBottom:'MapBrand',dotFill:'MapUIFrame99A',dotStroke:'MapBrand',activeFill:'MapUIFrame99A',activeStroke:'MapBrand',cursorColor:'MapText06A',tooltipBg:'MapUIFrame99C',tooltipBorder:'MapUIFrame09A',tooltipLabelColor:'MapText06A',tooltipText:'MapBrand',xColor:'MapText06A',yColor:'MapText06A',axisColor:'MapUIFrame08A'};
function chartToken(c,name){return DESIGN_TOKENS[c.tokenTheme||'light'][name];}
function resolveChartTokens(config,theme='light'){
 const c={...config,colors:[...config.colors],tokenTheme:theme};
 for(const [field,name] of Object.entries(config.tokenBindings||{})){
  const value=DESIGN_TOKENS[theme][name];if(!value)continue;
  if(field.startsWith('series'))c.colors[Number(field.slice(6))]=value;else c[field]=value;
 }
 return c;
}

