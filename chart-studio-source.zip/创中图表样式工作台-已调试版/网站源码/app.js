const h=React.createElement,{useState,useEffect,useRef}=React;
const charts=[['article','趋势图','chart-line','Recharts'],['traffic','饼状图','chart-pie-slice','ECharts'],['gender','双饼状图','intersect','ECharts'],['age','年龄分布柱状图','chart-bar','ECharts'],['region','地域分布','map-trifold','ECharts']];
const legacyChartIds=['works','engagement','followers'];
const initial={trafficContentFill:true,trafficContentWidth:600,trafficContentAlign:'center',trafficChartLegendGap:24,insetFrameColor:DESIGN_TOKENS.light.MapText06A,insetFrameWidth:1,insetFrameOpacity:90,islandShapeMode:'outline',islandStrokeColor:DESIGN_TOKENS.light.MapUIFrame99A,islandStrokeWidth:.8,islandStrokeOpacity:100,islandHoverStrokeColor:DESIGN_TOKENS.light.MapBrand,islandHoverStrokeWidth:1.5,mapAutoHeight:true,mapLabelSize:6,mapLabelColor:DESIGN_TOKENS.light.MapText06A,mapBoundaryMode:'full',distributionLayout:'auto',distributionGap:32,distributionSplit:52,genderIconSize:32,genderIconOpacity:60,regionPercentDecimals:2,trafficLegendGap:16,trafficLegendRowGap:16,regionRankVersion:1,regionBarColor:DESIGN_TOKENS.light.MapBrand,regionBarWidth:10,regionBarRadius:8,regionBarOpacity:100,regionRankCount:5,regionRankGradient:true,regionRankEndOpacity:28,regionRankNameColor:DESIGN_TOKENS.light.MapText06A,regionRankValueColor:DESIGN_TOKENS.light.MapText06A,regionRankNameSize:12,regionRankValueSize:12,regionRankShowNames:true,regionRankShowValues:true,regionRankNumberFormat:'raw',regionBarTrack:false,regionTrackColor:DESIGN_TOKENS.light.MapUIFrame10A,yAutoWidth:true,trafficPaletteVersion:2,trafficGradientStart:100,trafficGradientEnd:70,tooltipMinWidth:160,tooltipGap:24,tooltipNameColor:DESIGN_TOKENS.light.MapText03A,mapStrokeColor:DESIGN_TOKENS.light.MapUIFrame99A,mapStrokeWidth:.8,mapStrokeOpacity:100,mapStrokeType:'solid',mapHoverStrokeColor:DESIGN_TOKENS.light.MapBrand,mapHoverStrokeWidth:1.5,mapBoundaryColor:DESIGN_TOKENS.light.MapText06A,mapBoundaryWidth:1,mapBoundaryOpacity:90,seriesOpacity:80,mobileWidthVersion:1,distributionMetric:'readers',ecStyleVersion:1,tokenSchema:1,tokenTheme:'light',tokenBindings:{...DEFAULT_TOKEN_BINDINGS},_revision:3,colors:[DESIGN_TOKENS.light.MapBrand,DESIGN_TOKENS.light.MapUIAccentC,DESIGN_TOKENS.light.MapPass,DESIGN_TOKENS.light.MapUIAccentB,DESIGN_TOKENS.light.MapHighlight,DESIGN_TOKENS.light.MapCriticalTip,DESIGN_TOKENS.light.MapPositiveAlt,DESIGN_TOKENS.light.MapAI],bg:DESIGN_TOKENS.light.MapUIFrame99A,text:DESIGN_TOKENS.light.MapText06A,gridColor:DESIGN_TOKENS.light.MapUIFrame09A,width:2,opacity:12,font:11,height:160,radius:10,inner:65,bar:24,smooth:true,dots:true,grid:true,legend:false,tooltip:true,labels:false,animation:false,type:'area',title:'',note:'注：最多展示 30 天的数据',period:7,metric:'exposure',showNote:true,
widthMode:'fixed',cardWidth:393,marginTop:10,marginRight:8,marginBottom:4,marginLeft:0,curve:'monotone',lineDash:'solid',lineCap:'round',lineOpacity:100,fillEnabled:true,fillTop:DESIGN_TOKENS.light.MapBrand,fillBottom:DESIGN_TOKENS.light.MapBrand,fillEndOpacity:0,
dotShape:'circle',dotRadius:3,dotFill:DESIGN_TOKENS.light.MapUIFrame99A,dotStroke:DESIGN_TOKENS.light.MapBrand,dotStrokeWidth:1.5,dotOpacity:100,hoverDot:true,activeShape:'circle',activeRadius:4,activeFill:DESIGN_TOKENS.light.MapUIFrame99A,activeStroke:DESIGN_TOKENS.light.MapBrand,activeStrokeWidth:2,activeOpacity:100,
hoverLine:true,cursorColor:DESIGN_TOKENS.light.MapText06A,cursorWidth:1,cursorDash:'dashed',cursorOpacity:100,tooltipBg:DESIGN_TOKENS.light.MapUIFrame99A,tooltipBorder:DESIGN_TOKENS.light.MapUIFrame09A,tooltipBorderWidth:1,tooltipRadius:8,tooltipPadding:12,tooltipOffset:12,tooltipShadow:true,tooltipDate:true,tooltipName:true,tooltipUnit:true,tooltipLabelColor:DESIGN_TOKENS.light.MapText06A,tooltipLabelSize:11,tooltipText:DESIGN_TOKENS.light.MapBrand,tooltipStyleVersion:1,tooltipFont:13,tooltipBold:true,
xShow:true,xColor:DESIGN_TOKENS.light.MapText06A,xFont:11,xAngle:0,xHeight:26,xGap:30,xTickMargin:8,xPadding:0,xInterval:'auto',xAxisLine:false,xTickLine:false,yShow:true,yColor:DESIGN_TOKENS.light.MapText06A,yFont:11,yWidth:32,yTickMargin:8,yTicks:5,yFormat:'compact',yDecimals:1,yMin:0,yMaxAuto:true,yMax:4000,yAxisLine:false,yTickLine:false,axisColor:DESIGN_TOKENS.light.MapUIFrame08A,gridHorizontal:true,gridVertical:false,gridWidth:1,gridDash:'solid',gridOpacity:100,animationDuration:400};
function normalizeConfig(v={},device='mobile',id='article'){
  const c={...initial,cardWidth:device==='mobile'?393:820};
  for(const k in initial)if(v[k]!==undefined)c[k]=v[k];
  if(v._revision!==3){c._revision=3;c.height=['works','engagement','followers','article'].includes(id)?160:(v.height||250);c.dots=true;c.curve='monotone';c.animation=false;c.fillTop=c.colors[0];c.fillBottom=c.colors[0];c.dotStroke=c.colors[0];c.activeStroke=c.colors[0];}
  if(v.tooltipStyleVersion!==1){c.tooltipStyleVersion=1;c.tooltipText=DESIGN_TOKENS.light.MapBrand;c.hoverDot=true;}
  c.tokenBindings={...DEFAULT_TOKEN_BINDINGS};
  for(const [field,name] of Object.entries(v.tokenBindings||{}))if(field in DEFAULT_TOKEN_BINDINGS && name in DESIGN_TOKENS.light)c.tokenBindings[field]=name;
  c.colors=initial.colors.map((v,i)=>c.colors[i]||v);
  if(['traffic','gender','age','region'].includes(id)&&v.ecStyleVersion!==1){
    Object.assign(c,{ecStyleVersion:1,height:({traffic:350,gender:210,age:250,region:620})[id],inner:87,bar:10,radius:8,font:12,legend:true,labels:id==='region'});
    for(let i=0;i<8;i++)c.tokenBindings['series'+i]=DEFAULT_TOKEN_BINDINGS['series'+i];
    if(id==='gender')c.tokenBindings.series1='MapLiveBrand';
  }
  if(id==='region'&&v.mapLabelSize===undefined){c.mapLabelSize=Math.max(5,Number((c.font*.47).toFixed(1)));c.tokenBindings.mapLabelColor=c.tokenBindings.text;}
  if(id==='region'&&v.regionRankVersion!==1){c.regionRankVersion=1;c.regionBarWidth=c.bar;c.regionBarRadius=c.radius;c.regionRankNameSize=c.font;c.regionRankValueSize=c.font;c.tokenBindings.regionBarColor=c.tokenBindings.series0;c.tokenBindings.regionRankNameColor=c.tokenBindings.text;c.tokenBindings.regionRankValueColor=c.tokenBindings.text;}
  if(id==='traffic'&&v.trafficPaletteVersion!==2){c.trafficPaletteVersion=2;c.seriesOpacity=100;Array.from({length:8},(_,i)=>i<4?'MapBrandAlt':'MapBrand').forEach((token,i)=>c.tokenBindings['series'+i]=token);}
  if(device==='mobile'&&v.mobileWidthVersion!==1&&(!v.cardWidth||v.cardWidth===375))c.cardWidth=393;c.mobileWidthVersion=1;
  const meta=distributionMeta(id,c.distributionMetric);if(meta){c.distributionMetric=meta[0];c.dataLabel=meta[1];c.dataUnit=meta[2];}
  return c;
}
const TOOLTIP_KEYS=['tooltip',...Object.keys(initial).filter(k=>k.startsWith('tooltip')&&k!=='tooltipStyleVersion')];
function pickTooltip(config){return {...Object.fromEntries(TOOLTIP_KEYS.map(k=>[k,config[k]??initial[k]])),tokenBindings:Object.fromEntries(Object.entries(config.tokenBindings||DEFAULT_TOKEN_BINDINGS).filter(([k])=>TOOLTIP_KEYS.includes(k)))};}
function getSharedTooltip(saved){return pickTooltip(saved.sharedTooltip||normalizeConfig(saved.configs?.['article-mobile']||{},'mobile','article'));}
function applySharedTooltip(config,shared){return {...config,...shared,tokenBindings:{...config.tokenBindings,...shared.tokenBindings}};}
const APPEARANCE_KEYS=['bg','marginTop','marginRight','marginBottom','marginLeft','xShow','xColor','xFont','xAngle','xHeight','xGap','xTickMargin','xPadding','xInterval','xAxisLine','xTickLine','yShow','yColor','yFont','yAutoWidth','yWidth','yTickMargin','yTicks','yAxisLine','yTickLine','axisColor','grid','gridColor','gridHorizontal','gridVertical','gridWidth','gridDash','gridOpacity','hoverLine','cursorColor','cursorWidth','cursorDash','cursorOpacity'];
function pickAppearance(config){return {...Object.fromEntries(APPEARANCE_KEYS.map(k=>[k,config[k]??initial[k]])),tokenBindings:Object.fromEntries(Object.entries(config.tokenBindings||DEFAULT_TOKEN_BINDINGS).filter(([k])=>APPEARANCE_KEYS.includes(k)))};}
function getSharedAppearance(saved){return pickAppearance(saved.sharedAppearance||normalizeConfig(saved.configs?.['article-mobile']||{},'mobile','article'));}
function applySharedAppearance(config,shared){return {...config,...shared,tokenBindings:{...config.tokenBindings,...shared.tokenBindings}};}
function escapeTooltip(value){return String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
function tooltipHtml(c,label,name,value,unit){
 const e=escapeTooltip,display=String(value)+(c.tooltipUnit&&unit&&unit!=='次'?(unit==='%'?'%':' '+unit):'');
 return `<div class="studio-tooltip" style="box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif;background:${c.tooltipBg};border:${c.tooltipBorderWidth}px solid ${c.tooltipBorder};border-radius:${c.tooltipRadius}px;padding:${c.tooltipPadding}px;box-shadow:${c.tooltipShadow?'0 5px 20px '+chartToken(c,'MapUIFrame01A')+'20':'none'};min-width:${c.tooltipMinWidth}px;max-width:100%;line-height:1.45">${c.tooltipDate?`<div class="tooltip-data-date" style="font-size:${c.tooltipLabelSize}px;color:${c.tooltipLabelColor};margin-bottom:6px">${e(label)}</div>`:''}<div style="display:flex;align-items:baseline;justify-content:space-between;gap:${c.tooltipGap}px;font-size:${c.tooltipFont}px">${c.tooltipName?`<span class="tooltip-data-name" style="color:${c.tooltipNameColor};font-weight:500;white-space:nowrap">${e(name)}</span>`:''}<span class="tooltip-data-value" style="color:${c.tooltipText};font-weight:${c.tooltipBold?600:400};text-align:right;margin-left:auto;font-variant-numeric:tabular-nums;white-space:nowrap">${e(display)}</span></div></div>`;
}
const metrics=[['exposure','曝光数','次',1],['read','阅读数','次',.72],['ctr','推荐页点击率','%',.002],['agree','赞同数','次',.045],['like','喜欢数','次',.022],['comment','评论数','次',.013],['collect','收藏数','次',.018],['share','分享数','次',.009],['positive','正向互动率','%',.003],['duration','平均阅读时长','秒',.018]];
const trend=Array.from({length:30},(_,i)=>({name:`11-${String(i+1).padStart(2,'0')}`,value:i>=23?[1100,1100,3800,1500,1800,1100,1300][i-23]:Math.round(900+(i%5)*220+Math.sin(i)*260)}));
const defaults={article:trend,
 traffic:[{name:'APP 首页推荐',value:39.84},{name:'APP 首页关注',value:26.15},{name:'APP 搜索',value:12.09},{name:'APP 个人页',value:9.88},{name:'PC 首页推荐',value:7.86},{name:'PC 首页关注',value:3.07},{name:'PC 搜索',value:.87},{name:'PC 个人页',value:.24}],
 gender:[{name:'男性',value:1345},{name:'女性',value:345}],
 age:[{name:'0–18',value:330},{name:'18–22',value:530},{name:'22–30',value:690},{name:'30–45',value:620},{name:'45+',value:260}],
 region:[{name:'广东省',value:1848},{name:'山东省',value:1648},{name:'河南省',value:848},{name:'江苏省',value:424},{name:'浙江省',value:224},{name:'四川省',value:180},{name:'湖北省',value:150},{name:'湖南省',value:130},{name:'北京市',value:120},{name:'上海市',value:100},{name:'福建省',value:98},{name:'安徽省',value:90},{name:'辽宁省',value:85},{name:'云南省',value:78},{name:'广西壮族自治区',value:70},{name:'河北省',value:65},{name:'陕西省',value:60},{name:'江西省',value:50},{name:'黑龙江省',value:45},{name:'吉林省',value:40},{name:'重庆市',value:38},{name:'贵州省',value:36},{name:'天津市',value:33},{name:'山西省',value:30},{name:'内蒙古自治区',value:28},{name:'新疆维吾尔自治区',value:24},{name:'甘肃省',value:20},{name:'海南省',value:16},{name:'宁夏回族自治区',value:13},{name:'青海省',value:10},{name:'西藏自治区',value:8},{name:'台湾省',value:5},{name:'香港特别行政区',value:3},{name:'澳门特别行政区',value:2}]};
legacyChartIds.forEach((id,n)=>{defaults[id]=trend.map(d=>({...d,value:Math.round(d.value/(n+1))}));});
const distributionMetrics={
 traffic:[['readers','阅读来源','次'],['exposure','曝光来源','次'],['interactors','互动来源','次']],
 gender:[['readers','读者性别','人'],['followers','粉丝性别','人'],['interactors','互动用户性别','人']],
 age:[['readers','读者年龄','人'],['followers','粉丝年龄','人'],['interactors','互动用户年龄','人']],
 region:[['readers','读者地域','%'],['followers','粉丝地域','%'],['interactors','互动用户地域','%']]};
function distributionMeta(id,metric){return distributionMetrics[id]?.find(m=>m[0]===metric)||distributionMetrics[id]?.[0];}
function distributionSample(id,metric){
 if(id==='gender')return defaults[id].map((d,i)=>({...d,value:metric==='followers'?[810,620][i]:metric==='interactors'?[140,210][i]:d.value}));
 return defaults[id].map((d,i)=>({...d,value:Math.round(d.value*(id==='traffic'?100:1)*(metric==='exposure'?350*[1.12,.82,1.35,.8,1.6,.75,1.15,.9][i%8]:metric==='followers'?.8*[1.25,.62,1.08,1.35,.75][i%5]:metric==='interactors'?.18*[.55,1.8,1.4,1,.75][i%5]:1))}));
}
function validDataKey(key){return !!defaults[key]||metrics.some(m=>key==='article-'+m[0])||Object.entries(distributionMetrics).some(([id,list])=>list.some(m=>key===id+'-'+m[0]));}
function Icon({name}){return h('i',{className:'ph ph-'+name,'aria-hidden':true});}
function icon(name){return h(Icon,{name})}
function Select({children,value,onChange,className='',tokenColors,...props}){
 const [open,setOpen]=useState(false),[active,setActive]=useState(0),[position,setPosition]=useState({}),root=useRef(),menu=useRef(),uid=React.useId(),typing=useRef({text:'',time:0});
 const options=[];function collect(nodes,group){React.Children.forEach(nodes,node=>{if(!React.isValidElement(node))return;if(node.type==='optgroup')collect(node.props.children,node.props.label);else if(node.type==='option')options.push({value:String(node.props.value),label:node.props.children,group});});}collect(children);
 const index=Math.max(0,options.findIndex(o=>o.value===String(value))),chosen=options[index];
 function show(){const r=root.current.getBoundingClientRect(),below=innerHeight-r.bottom-12,above=r.top-12,up=below<180&&above>below;setPosition({position:'fixed',left:Math.max(8,Math.min(r.left,innerWidth-Math.max(r.width,180)-8)),width:Math.min(Math.max(r.width,180),innerWidth-16),maxHeight:Math.min(320,Math.max(100,up?above:below)),...(up?{bottom:innerHeight-r.top+6}:{top:r.bottom+6})});setActive(index);setOpen(true);}
 function choose(i){if(!options[i])return;onChange?.({target:{value:options[i].value}});setOpen(false);root.current.querySelector('button')?.focus();}
 useEffect(()=>{if(!open)return;function outside(e){if(!root.current?.contains(e.target)&&!menu.current?.contains(e.target))setOpen(false);}function scroll(e){if(!menu.current?.contains(e.target))setOpen(false);}document.addEventListener('pointerdown',outside);window.addEventListener('resize',scroll);window.addEventListener('scroll',scroll,true);return()=>{document.removeEventListener('pointerdown',outside);window.removeEventListener('resize',scroll);window.removeEventListener('scroll',scroll,true)}},[open]);
 useEffect(()=>{if(open)menu.current?.querySelector('[data-index="'+active+'"]')?.scrollIntoView({block:'nearest'});},[open,active]);
 function keys(e){if(e.key==='Escape'){setOpen(false);return}if(e.key==='Tab'){setOpen(false);return}if(['ArrowDown','ArrowUp','Home','End','Enter',' '].includes(e.key)){e.preventDefault();if(!open){show();return}if(e.key==='Enter'||e.key===' '){choose(active);return}setActive(i=>e.key==='Home'?0:e.key==='End'?options.length-1:(i+(e.key==='ArrowDown'?1:-1)+options.length)%options.length);return}if(e.key.length===1&&!e.ctrlKey&&!e.metaKey){const now=Date.now(),query=(now-typing.current.time>700?'':typing.current.text)+e.key.toLowerCase();typing.current={text:query,time:now};const i=options.findIndex(o=>String(o.label).toLowerCase().startsWith(query));if(i>=0){if(open)setActive(i);else choose(i);}}}
 return h('span',{className:'select-shell',ref:root},h('button',{...props,type:'button',role:'combobox','aria-haspopup':'listbox','aria-expanded':open,'aria-controls':open?uid:undefined,'aria-activedescendant':open?uid+'-'+active:undefined,className:'select-trigger '+className,onClick:()=>open?setOpen(false):show(),onKeyDown:keys},h('span',{className:'select-value'},chosen?.label),h(Icon,{name:'caret-down'})),open&&ReactDOM.createPortal(h('div',{className:'select-menu'+(tokenColors?' token-menu':''),id:uid,ref:menu,role:'listbox','aria-label':props['aria-label'],style:position},options.map((o,i)=>h(React.Fragment,{key:o.value},o.group&&options[i-1]?.group!==o.group&&h('div',{className:'select-group',role:'presentation'},o.group),h('button',{type:'button',role:'option',id:uid+'-'+i,'aria-selected':o.value===String(value),'data-index':i,className:'select-option'+(i===active?' highlighted':''),onMouseEnter:()=>setActive(i),onMouseDown:e=>e.preventDefault(),onClick:()=>choose(i)},tokenColors&&h('span',{className:'option-swatch',style:{background:tokenColors[o.value]},'aria-hidden':true}),h('span',{className:'option-label'},o.label),o.value===String(value)&&h(Icon,{name:'check'}))))),document.body));
}

function tintColor(color,bg,amount){const rgb=x=>[1,3,5].map(i=>parseInt(x.slice(i,i+2),16));const a=rgb(color),b=rgb(bg);return '#'+a.map((n,i)=>Math.round(n*amount+b[i]*(1-amount)).toString(16).padStart(2,'0')).join('');}
function shortProvince(name){return name.replace(/特别行政区|维吾尔自治区|壮族自治区|回族自治区|自治区|省|市/g,'');}
const MAP_LABEL_ANCHORS={'甘肃省':[95.939011,39.973893],'河北省':[114.8,38.15],'天津市':[117.347043,39.288036],'香港特别行政区':[114.173355,22.320048],'澳门特别行政区':[113.54909,22.198951]};
function mapLabelLayout(params,c){
 const f=c.mapLabelSize;
 const offsets={'香港':{dx:f*1.1,dy:f*.1,align:'left'},'澳门':{dx:-f*.6,dy:f*.6,align:'right'},'天津':{dx:f*.9,dy:f*.2,align:'left'},'河北':{dx:-f*.4,dy:f*.3,align:'center'}};
 return offsets[params.text]||{};
}
function prepareChinaMap(geo,mode='full'){
 const features=[];
 for(const feature of geo.features){
  const boundary=!feature.properties.name||feature.properties.name==='南海边界';
  if(boundary&&mode==='hidden')continue;
  let f=boundary?{...feature,properties:{...feature.properties,name:'南海边界'}}:feature;
  const anchor=MAP_LABEL_ANCHORS[f.properties.name];if(anchor)f={...f,properties:{...f.properties,cp:anchor}};
  if(mode==='inset'){
   const polygons=f.geometry.type==='MultiPolygon'?f.geometry.coordinates:[f.geometry.coordinates];
   // Retain the boundary in the main map and clip only to its viewport.
   const kept=polygons.map(poly=>poly.map(ring=>clipMapRing(ring,[73,18,136,54])).filter(ring=>ring.length>=4)).filter(poly=>poly.length);
   if(!kept.length)continue;f={...f,geometry:{type:'MultiPolygon',coordinates:kept}};
  }
  features.push(f);
 }
 return {...geo,features};
}
// Keep a bounded geographic viewport for the inset, including coastal context.
function clipMapRing(ring,bounds){
 let points=ring.slice();
 for(const [axis,edge,sign] of [[0,bounds[0],1],[0,bounds[2],-1],[1,bounds[1],1],[1,bounds[3],-1]]){
  const output=[];
  for(let i=0;i<points.length;i++){
   const a=points[i],b=points[(i+1)%points.length],insideA=(a[axis]-edge)*sign>=0,insideB=(b[axis]-edge)*sign>=0;
   if(insideA)output.push(a);
   if(insideA!==insideB){const t=(edge-a[axis])/(b[axis]-a[axis]);output.push([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])]);}
  }
  points=output;if(!points.length)break;
 }
 if(points.length<3)return [];
 if(points[0][0]!==points.at(-1)[0]||points[0][1]!==points.at(-1)[1])points.push([...points[0]]);
 return points;
}
function prepareSouthChinaMap(geo,dots=false){
 const features=[];
 for(const source of prepareChinaMap(geo).features){
  const polygons=source.geometry.type==='MultiPolygon'?source.geometry.coordinates:[source.geometry.coordinates];
  const coordinates=[],centers=[];
  for(const poly of polygons){
   const clipped=poly.map(ring=>clipMapRing(ring,[105,2.8,124.8,24])).filter(ring=>ring.length>=4);
   if(!clipped.length)continue;
   const ring=clipped[0],xs=ring.map(p=>p[0]),ys=ring.map(p=>p[1]),west=Math.min(...xs),east=Math.max(...xs),south=Math.min(...ys),north=Math.max(...ys);
   if(dots&&source.properties.name==='海南省'&&north<18&&east-west<1&&north-south<1){
    const x=(west+east)/2,y=(south+north)/2;
    // Merge only visually overlapping reef markers, preserving their real positions.
    if(centers.some(p=>Math.hypot((p[0]-x)*.75,p[1]-y)<.45))continue;
    centers.push([x,y]);
    coordinates.push([Array.from({length:17},(_,i)=>{const a=i/16*Math.PI*2;return [x+Math.cos(a)*.2/.75,y+Math.sin(a)*.2]})]);
   }else coordinates.push(clipped);
  }
  if(coordinates.length)features.push({...source,geometry:{type:'MultiPolygon',coordinates}});
 }
 return {type:'FeatureCollection',features};
}
const CHINA_MAP_BOUNDS={};
function chinaMapBounds(geo){
 let west=Infinity,east=-Infinity,south=Infinity,north=-Infinity;
 for(const f of geo.features){const polys=f.geometry.type==='MultiPolygon'?f.geometry.coordinates:[f.geometry.coordinates];for(const poly of polys)for(const ring of poly)for(const [x,y] of ring){west=Math.min(west,x);east=Math.max(east,x);south=Math.min(south,y);north=Math.max(north,y);}}
 return {ratio:(east-west)*.75/(north-south),west,east,south,north};
}
function chartPlotHeight(id,c,data,mobile,width){
 if(id!=='region'||c.mapBoundaryMode!=='inset'||c.mapAutoHeight===false)return c.height;
 const horizontal=c.distributionLayout==='horizontal'||c.distributionLayout!=='vertical'&&!mobile;
 const mapWidth=horizontal?(width-(c.distributionGap??32))*(c.distributionSplit??52)/100:width;
 const mapHeight=Math.max(80,(mapWidth-16)/(CHINA_MAP_BOUNDS.inset?.ratio||1.33)+16),rankHeight=Math.max(100,Math.min(c.regionRankCount,data.length)*(c.regionBarWidth+24));
 return Math.ceil(horizontal?Math.max(mapHeight+(c.legend?34:8),rankHeight+24):mapHeight+42+rankHeight+12);
}
function fitChinaMap(mode,width,height){
 const ratio=CHINA_MAP_BOUNDS[mode]?.ratio||1.33,pad=8,availableWidth=Math.max(1,width-pad*2),availableHeight=Math.max(1,height-pad*2);
 const drawWidth=Math.min(availableWidth,availableHeight*ratio),drawHeight=drawWidth/ratio;
 return {width:drawWidth,height:drawHeight,left:(width-drawWidth)/2,top:(height-drawHeight)/2,center:[width/2,height/2],size:Math.max(drawWidth,drawHeight)};
}
function registerChinaMaps(geo){
 for(const mode of ['full','inset','hidden']){const map=prepareChinaMap(geo,mode);CHINA_MAP_BOUNDS[mode]=chinaMapBounds(map);echarts.registerMap('china-'+mode,map);}
 echarts.registerMap('china-south',prepareSouthChinaMap(geo));
 echarts.registerMap('china-south-dots',prepareSouthChinaMap(geo,true));
}
function alphaColor(hex,opacity){return 'rgba('+[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)).join(',')+','+opacity/100+')';}
const GENDER_SVGS=["<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g>\n<path d=\"M20.6073 8.10977C20.9376 8.12571 21.2608 8.21149 21.5555 8.36146C21.8503 8.51142 22.1099 8.72215 22.3173 8.97977C22.7543 9.50977 22.9713 10.2088 22.9173 10.9148L22.0273 20.6488C21.9773 21.3248 21.4533 21.8458 20.8243 21.8438H19.1743L17.9813 30.1458C17.9283 30.5154 17.7439 30.8536 17.4617 31.0983C17.1796 31.343 16.8187 31.4777 16.4453 31.4778H15.4873C15.1078 31.4778 14.7415 31.3389 14.4576 31.0872C14.1736 30.8355 13.9917 30.4885 13.9463 30.1118L12.9433 21.8438H11.1983C11.0383 21.8572 10.8774 21.8369 10.7258 21.7841C10.5742 21.7314 10.4354 21.6475 10.3183 21.5378C10.0703 21.3057 9.92007 20.9877 9.89827 20.6488L9.00827 10.9148C8.95124 10.1999 9.17832 9.49133 9.64027 8.94277C9.85766 8.68367 10.1289 8.47502 10.4351 8.33134C10.7412 8.18766 11.0751 8.11239 11.4133 8.11077L20.6073 8.10977ZM14.4933 0.408768C14.9157 0.142358 15.4049 0.000976562 15.9043 0.000976562C16.4037 0.000976562 16.8929 0.142358 17.3153 0.408768C18.1893 0.952768 18.7273 1.95777 18.7263 3.04577C18.7263 4.13377 18.1893 5.13877 17.3163 5.68277C16.8938 5.94938 16.4044 6.09087 15.9048 6.09087C15.4052 6.09087 14.9158 5.94938 14.4933 5.68277C13.6203 5.13877 13.0823 4.13277 13.0823 3.04577C13.0823 1.95777 13.6203 0.952768 14.4933 0.408768Z\" fill=\"currentColor\"/>\n</g>\n</svg>\n", "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g>\n<path d=\"M18.4254 8.11001C18.7558 8.12596 19.079 8.21174 19.3737 8.3617C19.6685 8.51166 19.9281 8.7224 20.1354 8.98001C20.5724 9.51001 20.7273 10.1819 20.7273 10.1819L23.4818 20.649C23.4318 21.325 22.9078 21.846 22.2788 21.844H19.1743L17.9813 30.146C17.9283 30.5157 17.7439 30.8539 17.4617 31.0985C17.1796 31.3432 16.8187 31.4779 16.4453 31.478H15.4873C15.1078 31.4781 14.7415 31.3391 14.4576 31.0874C14.1736 30.8357 13.9917 30.4887 13.9463 30.112L12.9433 21.844H9.74373C9.5838 21.8574 9.42284 21.8371 9.27126 21.7844C9.11967 21.7317 8.98084 21.6477 8.86373 21.538C8.61573 21.3059 8.46553 20.988 8.44373 20.649L11.2727 10.1819C11.2727 10.1819 11.3601 9.49157 11.8221 8.94301C12.0395 8.68391 12.3107 8.47527 12.6169 8.33158C12.9231 8.1879 13.2569 8.11264 13.5951 8.11101L18.4254 8.11001ZM14.4933 0.409012C14.9157 0.142603 15.4049 0.0012207 15.9043 0.0012207C16.4037 0.0012207 16.8929 0.142603 17.3153 0.409012C18.1893 0.953012 18.7273 1.95801 18.7263 3.04601C18.7263 4.13401 18.1893 5.13901 17.3163 5.68301C16.8938 5.94962 16.4044 6.09112 15.9048 6.09112C15.4052 6.09112 14.9158 5.94962 14.4933 5.68301C13.6203 5.13901 13.0823 4.13301 13.0823 3.04601C13.0823 1.95801 13.6203 0.953012 14.4933 0.409012Z\" fill=\"currentColor\"/>\n</g>\n</svg>\n"];
function genderIcon(index,color){return 'data:image/svg+xml;charset=UTF-8,'+encodeURIComponent(GENDER_SVGS[index].replaceAll('currentColor',color));}
function formatYAxisValue(value,c,unit){return c.yFormat==='raw'?String(value):(c.yFormat==='percent'||c.yFormat==='compact'&&unit==='%')?value+'%':c.yFormat==='compact'&&Math.abs(value)>=1000?Number((value/1000).toFixed(c.yDecimals))+'K':String(value);}
function yAxisLayout(c,data,unit='次'){
 const count=Math.max(2,c.yTicks),min=c.yMin,top=Math.max(min,...data.map(d=>d.value)),round=v=>Number(v.toPrecision(12));
 let max,step;
 if(c.yMaxAuto){const span=Math.max(top-min,top===min?Math.abs(min)*.1||1:0),raw=span/(count-1),power=Math.pow(10,Math.floor(Math.log10(raw))),ratio=raw/power;step=([1,2,2.5,5,10].find(n=>n>=ratio)||10)*power;max=round(min+Math.ceil(span/step)*step);}
 else{max=Math.max(c.yMax,min+1);step=(max-min)/(count-1);}
 const ticks=Array.from({length:Math.round((max-min)/step)+1},(_,i)=>round(min+i*step));
 const labels=ticks.map(v=>formatYAxisValue(v,c,unit));
 let fontFamily='-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif',context;
 if(typeof document!=='undefined'){if(typeof getComputedStyle==='function'&&document.body)fontFamily=getComputedStyle(document.body).fontFamily;const canvas=yAxisLayout.canvas||(yAxisLayout.canvas=document.createElement('canvas'));context=canvas.getContext('2d');if(context)context.font=c.yFont+'px '+fontFamily;}
 const textWidth=Math.max(...labels.map(label=>context?context.measureText(label).width:[...label].reduce((w,ch)=>w+(ch==='.'||ch===','?.3:ch==='-'?.4:.65)*c.yFont,0)));
 const width=!c.yShow?0:c.yAutoWidth===false?c.yWidth:Math.max(24,Math.ceil(textWidth)+c.yTickMargin+(c.yTickLine?6:0)+6);
 return {min,max,step,ticks,width};
}
function optionFor(id,c,data,mobile,width=c.cardWidth,regionActions=null){
 const w=Math.max(200,width),height=chartPlotHeight(id,c,data,mobile,w),f=c.font,total=data.reduce((n,d)=>n+d.value,0)||1;
 const horizontal=c.distributionLayout==='horizontal'||c.distributionLayout!=='vertical'&&!mobile,gap=c.distributionGap??32,leftWidth=(w-gap)*(c.distributionSplit??52)/100,rightLeft=leftWidth+gap;
 const text=(x,y,value,fill=c.text,size=f,align='left')=>({type:'text',silent:true,x,y,style:{text:value,fill,fontSize:size,fontFamily:'Arial, sans-serif',align,verticalAlign:'middle'}});
 const dot=(x,y,color,opacity=(c.seriesOpacity??80)/100)=>({type:'circle',silent:true,shape:{cx:x,cy:y,r:4},style:{fill:color,opacity}});
 const base={backgroundColor:c.bg,color:c.colors,textStyle:{fontSize:f,color:c.text},animation:c.animation,tooltip:{show:c.tooltip,trigger:'item',confine:true,backgroundColor:'transparent',borderWidth:0,padding:0,extraCssText:'box-shadow:none;',renderMode:'html',transitionDuration:0,formatter:params=>{const p=Array.isArray(params)?params[0]:params;if(!p||p.name==='南海边界'||p.name==='其余')return '';return tooltipHtml(c,c.dataLabel||'',p.name,Number.isFinite(+p.value)?(id==='region'?Number(p.value).toFixed(c.regionPercentDecimals):p.value):'—',c.dataUnit||'人');},position:(point,params,dom,rect,size)=>{const gap=c.tooltipOffset;return [Math.max(0,Math.min(point[0]+gap,size.viewSize[0]-size.contentSize[0])),Math.max(0,Math.min(point[1]+gap,size.viewSize[1]-size.contentSize[1]))]}},series:[],graphic:[]};
 if(id==='traffic'){
  const tw=Math.max(120,Math.min(w,c.trafficContentFill===false?c.trafficContentWidth:w)),gap=c.trafficChartLegendGap??24,rows=Math.ceil(data.length/2),rowHeight=f+c.trafficLegendRowGap,headerHeight=!mobile?f+20:0,legendHeight=c.legend?(rows-1)*rowHeight+f+headerHeight:0;
  const alignOffset=size=>c.trafficContentAlign==='left'?0:c.trafficContentAlign==='right'?w-size:(w-size)/2;
  const legendWidth=Math.min(tw*.48,Math.max(160,...data.map(d=>d.name.length*f*.6+f*5.2+28))),outer=Math.max(12,horizontal&&c.legend?Math.min((tw-legendWidth-gap)/2,height*.42):Math.min(tw*.30,(height-legendHeight-(c.legend?gap:0))/2));
  const groupWidth=horizontal&&c.legend?outer*2+gap+legendWidth:tw,offset=alignOffset(groupWidth),groupHeight=outer*2+(c.legend&&!horizontal?gap+legendHeight:0),top=Math.max(0,(height-groupHeight)/2),cx=horizontal&&c.legend?offset+outer:offset+tw/2,cy=horizontal?height/2:top+outer,legendLeft=offset+outer*2+gap,legendRight=legendLeft+legendWidth;
  const groupColor=i=>c.colors[i<rows?0:4],groupOpacity=i=>(c.trafficGradientStart+(c.trafficGradientEnd-c.trafficGradientStart)*(i%rows)/Math.max(1,(i<rows?rows:data.length-rows)-1))/100;
  base.series=[{name:c.dataLabel,type:'pie',radius:[outer*c.inner/100,outer],center:[cx,cy],startAngle:90,clockwise:true,minAngle:0,padAngle:1,avoidLabelOverlap:true,itemStyle:{borderWidth:0,borderRadius:c.radius,opacity:c.seriesOpacity/100},label:{show:c.labels,position:'inside',formatter:'{d}%',fontSize:f,color:c.bg},emphasis:{scale:true,scaleSize:4},data:data.map((d,i)=>({...d,itemStyle:{color:groupColor(i),opacity:groupOpacity(i)}}))}];
  base.graphic.push(text(cx,cy,c.dataLabel||'来源分布',c.text,f+1,'center'));
  if(c.legend&&horizontal){
   const rh=Math.min(rowHeight,(height-24)/Math.max(1,data.length)),startY=(height-rh*(data.length-1))/2;
   data.forEach((d,i)=>{const y=startY+i*rh;base.graphic.push(dot(legendLeft+4,y,groupColor(i),groupOpacity(i)),text(legendLeft+16,y,d.name,c.text,Math.min(f,Math.max(8,(legendWidth-80)/7))),text(legendRight-4,y,(d.value/total*100).toFixed(2)+'%',c.text,f,'right'));});
  }else if(c.legend){
   const columnWidth=(tw-c.trafficLegendGap)/2,columnLeft=i=>offset+(i?columnWidth+c.trafficLegendGap:0),legendTop=top+outer*2+gap;
   if(!mobile)base.graphic.push(text(columnLeft(0)+8,legendTop+f/2,'APP 端',c.colors[0],f),text(columnLeft(1)+8,legendTop+f/2,'PC 端',c.colors[4],f));
   data.forEach((d,i)=>{const col=i<rows?0:1,row=i%rows,x=columnLeft(col)+4,y=legendTop+headerHeight+f/2+row*rowHeight;base.graphic.push(dot(x+4,y,groupColor(i),groupOpacity(i)),text(x+16,y,d.name,c.text,Math.min(f,(columnWidth-72)/7)),text(columnLeft(col)+columnWidth-5,y,(d.value/total*100).toFixed(2)+'%',c.text,f,'right'));});
  }
 }
 if(id==='gender'){
  const outer=Math.max(12,Math.min(w*.185,(height-(c.legend?42:0))*.43)),cy=(height-(c.legend?42:0))/2;
  data.slice(0,2).forEach((d,i)=>{const cx=w*(i?.75:.25),color=c.colors[i],inner=outer*c.inner/100;
   base.series.push({name:c.dataLabel,type:'pie',radius:[inner,outer],center:[cx,cy],startAngle:90,clockwise:true,silent:false,label:{show:c.labels,position:'outside',formatter:p=>p.dataIndex===0?(d.value/total*100).toFixed(1)+'%':'',fontSize:f,color},labelLine:{show:false},emphasis:{scale:false},data:[{name:d.name,value:d.value,itemStyle:{color,borderRadius:c.radius,opacity:c.seriesOpacity/100}},{name:'其余',value:total-d.value,itemStyle:{color:tintColor(color,c.bg,.1)},tooltip:{show:false},emphasis:{disabled:true}}]});
   const iconSize=Math.min(c.genderIconSize,inner*1.4);base.graphic.push({type:'image',silent:true,x:cx-iconSize/2,y:cy-iconSize/2,style:{image:genderIcon(i,color),width:iconSize,height:iconSize,opacity:c.genderIconOpacity/100}});
   if(c.legend){const label=d.name+'  '+d.value+' 人';base.graphic.push(dot(cx-(label.length*f*.5)/2-10,height-18,color),text(cx+5,height-18,label,c.text,f,'center'));}
  });
 }
 const dash={solid:'solid',dashed:[6,4],dotted:[2,3]},axis={axisLine:{show:false},axisTick:{show:false},axisLabel:{color:c.text,fontSize:f},splitLine:{show:false}};
 if(id==='age'){
  const yAxis=yAxisLayout(c,data,c.dataUnit||'人');
  base.tooltip.trigger='axis';base.tooltip.axisPointer={type:c.hoverLine?'line':'none',lineStyle:{color:alphaColor(c.cursorColor,c.cursorOpacity),width:c.cursorWidth,type:dash[c.cursorDash]}};
  base.grid={left:yAxis.width+c.marginLeft+c.xPadding,right:c.marginRight+c.xPadding,top:c.marginTop,bottom:(c.xShow?c.xHeight:0)+c.marginBottom};
  const labelFormat=value=>formatYAxisValue(value,c,c.dataUnit||'人');
  const split={color:alphaColor(c.gridColor,c.gridOpacity),width:c.gridWidth,type:dash[c.gridDash]};
  base.xAxis={type:'category',show:c.xShow,data:data.map(d=>d.name),axisLine:{show:c.xAxisLine,lineStyle:{color:c.axisColor}},axisTick:{show:c.xTickLine,lineStyle:{color:c.axisColor}},axisLabel:{color:c.xColor,fontSize:c.xFont,rotate:-c.xAngle,interval:c.xInterval==='auto'?Math.max(0,Math.ceil((Math.max(...data.map(d=>d.name.length))*c.xFont*.6+c.xGap)/Math.max(1,(w-yAxis.width-c.marginRight-c.marginLeft-c.xPadding*2)/data.length))-1):Number(c.xInterval),margin:c.xTickMargin,hideOverlap:c.xInterval==='auto'},boundaryGap:true,splitLine:{show:c.grid&&c.gridVertical,lineStyle:split}};
  base.yAxis={type:'value',show:c.yShow,min:yAxis.min,max:yAxis.max,interval:yAxis.step,splitNumber:c.yTicks-1,axisLine:{show:c.yAxisLine,lineStyle:{color:c.axisColor}},axisTick:{show:c.yTickLine,lineStyle:{color:c.axisColor}},axisLabel:{color:c.yColor,fontSize:c.yFont,margin:c.yTickMargin,formatter:labelFormat},splitLine:{show:c.grid&&c.gridHorizontal,lineStyle:split}};
  base.series=[{name:c.dataLabel,type:'bar',barWidth:c.bar,itemStyle:{color:c.colors[0],borderRadius:[c.radius,c.radius,0,0]},data,label:{show:c.labels,position:'top',color:c.text,fontSize:f}}];
 }
 if(id==='region'){
  const regionData=data.map(d=>({...d,value:d.value/total*100}));
  const ranks=[...regionData].sort((a,b)=>b.value-a.value).slice(0,c.regionRankCount),max=Math.max(...regionData.map(d=>d.value),0),mapWidth=horizontal?leftWidth:w,mode=c.mapBoundaryMode||'full',naturalHeight=(mapWidth-16)/(CHINA_MAP_BOUNDS[mode]?.ratio||1.33)+16,mapHeight=horizontal?height-(c.legend?40:12):Math.min(height*.60,naturalHeight),barTop=horizontal?16:mapHeight+42,mapFrame=fitChinaMap(mode,mapWidth,mapHeight);
  base.visualMap={show:c.legend,type:'continuous',min:0,max:max||1,seriesIndex:1,left:4,top:mapHeight+6,orient:'horizontal',itemWidth:6,itemHeight:76,text:[max.toFixed(c.regionPercentDecimals)+'%','0%'],textGap:5,textStyle:{color:c.text,fontSize:f-1},calculable:false,inRange:{color:[tintColor(c.colors[0],c.bg,.12),c.colors[0]]},borderWidth:0};
  const rankValue=v=>Number(v).toFixed(c.regionPercentDecimals)+'%';
  base.grid={left:(horizontal?rightLeft:0)+(c.regionRankShowNames?Math.max(46,...ranks.map(d=>shortProvince(d.name).length*c.regionRankNameSize+16)):8),right:c.regionRankShowValues?Math.max(28,...ranks.map(d=>rankValue(d.value).length*c.regionRankValueSize*.65+12)):12,top:barTop,bottom:12};
  base.xAxis={type:'value',show:false,max:(max||1)*1.03};base.yAxis={...axis,type:'category',inverse:true,data:ranks.map(d=>shortProvince(d.name)),splitLine:{show:false},axisLabel:{show:c.regionRankShowNames,color:c.regionRankNameColor,fontSize:c.regionRankNameSize,margin:20}};
  base.series=[{name:c.dataLabel,type:'bar',barWidth:c.regionBarWidth,showBackground:c.regionBarTrack,backgroundStyle:{color:c.regionTrackColor,borderRadius:[0,c.regionBarRadius,c.regionBarRadius,0]},data:ranks.map((d,i)=>({...d,itemStyle:{color:c.regionBarColor,opacity:c.regionBarOpacity/100*(c.regionRankGradient?1-i/Math.max(1,ranks.length-1)*(1-c.regionRankEndOpacity/100):1),borderRadius:[0,c.regionBarRadius,c.regionBarRadius,0]}})),label:{show:c.regionRankShowValues,position:'right',distance:5,color:c.regionRankValueColor,fontSize:c.regionRankValueSize,formatter:p=>rankValue(p.value)},emphasis:{itemStyle:{color:c.regionBarColor}}},
   {name:c.dataLabel,type:'map',map:'china-'+(c.mapBoundaryMode||'full'),selectedMode:'single',select:{label:{show:c.labels,color:c.mapLabelColor},itemStyle:{areaColor:tintColor(c.colors[0],c.bg,.7),borderColor:c.mapHoverStrokeColor,borderWidth:c.mapHoverStrokeWidth}},aspectScale:.75,layoutCenter:mapFrame.center,layoutSize:mapFrame.size,roam:false,labelLayout:params=>mapLabelLayout(params,c),label:{show:c.labels,fontSize:c.mapLabelSize,color:c.mapLabelColor,formatter:p=>shortProvince(p.name)},itemStyle:{areaColor:tintColor(c.colors[0],c.bg,.12),borderColor:alphaColor(c.mapStrokeColor,c.mapStrokeOpacity),borderWidth:c.mapStrokeWidth,borderType:c.mapStrokeType},emphasis:{label:{show:c.labels,color:c.mapLabelColor,fontSize:c.mapLabelSize},itemStyle:{areaColor:tintColor(c.colors[0],c.bg,.7),borderColor:c.mapHoverStrokeColor,borderWidth:c.mapHoverStrokeWidth}},data:[...regionData,{name:'南海边界',itemStyle:{areaColor:alphaColor(c.mapBoundaryColor,c.mapBoundaryOpacity),borderColor:alphaColor(c.mapBoundaryColor,c.mapBoundaryOpacity),borderWidth:c.mapBoundaryWidth,borderType:c.mapStrokeType},label:{show:false},tooltip:{show:false},emphasis:{disabled:true}}]}];
  if(c.mapBoundaryMode==='inset'){
   const iw=Math.max(34,Math.min(90,mapFrame.width*.155)),ih=iw*1.48,ix=mapFrame.left+mapFrame.width-iw,iy=mapFrame.top+mapFrame.height-ih;
   base.graphic.push({type:'rect',silent:true,shape:{x:ix,y:iy,width:iw,height:ih},style:{fill:c.bg,stroke:alphaColor(c.insetFrameColor,c.insetFrameOpacity),lineWidth:c.insetFrameWidth}},text(ix+iw/2,iy+ih-7,'南海诸岛',c.mapLabelColor,Math.min(c.mapLabelSize,9),'center'));
   base.series.push({type:'map',map:c.islandShapeMode==='dots'?'china-south-dots':'china-south',selectedMode:'single',aspectScale:.75,left:ix+1,top:iy+1,width:iw-2,height:ih-17,silent:false,roam:false,label:{show:false},tooltip:{show:c.tooltip},emphasis:{label:{show:false},itemStyle:{areaColor:tintColor(c.colors[0],c.bg,.7),borderColor:c.islandHoverStrokeColor,borderWidth:c.islandHoverStrokeWidth}},select:{label:{show:false},itemStyle:{areaColor:tintColor(c.colors[0],c.bg,.7),borderColor:c.islandHoverStrokeColor,borderWidth:c.islandHoverStrokeWidth}},itemStyle:{areaColor:tintColor(c.colors[0],c.bg,.12),borderColor:alphaColor(c.islandStrokeColor,c.islandStrokeOpacity),borderWidth:c.islandStrokeWidth,borderType:c.mapStrokeType},data:[...regionData,{name:'南海边界',silent:true,tooltip:{show:false},emphasis:{disabled:true},select:{disabled:true},itemStyle:{areaColor:alphaColor(c.mapBoundaryColor,c.mapBoundaryOpacity),borderColor:alphaColor(c.mapBoundaryColor,c.mapBoundaryOpacity),borderWidth:c.mapBoundaryWidth}}]});
   // Larger hit area for the tiny Hainan island geometries, excluding northern context.
   base.graphic.push({type:'rect',name:'海南省附图交互区',z:100,silent:false,cursor:'pointer',tooltip:{show:c.tooltip,formatter:()=>{const hainan=regionData.find(d=>d.name==='海南省');return tooltipHtml(c,c.dataLabel||'','海南省',hainan?Number(hainan.value).toFixed(c.regionPercentDecimals):'—',hainan?'%':'');}},shape:{x:ix,y:iy+1+(ih-17)*.31,width:iw,height:ih-1-(ih-17)*.31},style:{fill:'rgba(0,0,0,0)'},onmouseover:e=>regionActions?.hover('海南省'),onmousemove:e=>regionActions?.hover('海南省'),onmouseout:()=>regionActions?.leave('海南省'),onclick:()=>regionActions?.select('海南省')});
  }
 }
 return base;
}
function createRegionActions(chart){
 let selectedName=null;
 const maps=()=>chart.getOption().series.map((s,i)=>s.type==='map'?i:-1).filter(i=>i>=0);
 const act=(type,name)=>{if(name&&name!=='南海边界')chart.dispatchAction({type,seriesIndex:maps(),name});};
 const actions={
  hover(name){act('highlight',name);},
  leave(name){act('downplay',name);},
  select(name){if(!name||name==='南海边界')return;const previous=selectedName;act('unselect',previous);selectedName=name===previous?null:name;act('select',selectedName);},
  restore(){act('select',selectedName);}
 };
 chart.on('mouseover',p=>{if(p.componentType==='series'&&p.seriesType==='map')actions.hover(p.name);});
 chart.on('mouseout',p=>{if(p.componentType==='series'&&p.seriesType==='map')actions.leave(p.name);});
 chart.on('click',p=>{if(p.componentType==='series'&&p.seriesType==='map')actions.select(p.name);});
 return actions;
}
function TrendDot({cx,cy,c,active=false}){
  if(!Number.isFinite(cx)||!Number.isFinite(cy))return null;
  const prefix=active?'active':'dot',r=c[prefix+'Radius'];
  return h(Recharts.Symbols,{className:active?'studio-active-dot':'studio-dot',cx,cy,type:c[prefix+'Shape'],size:c[prefix+'Shape']==='circle'?Math.PI*r*r:4*r*r,fill:c[prefix+'Fill'],stroke:c[prefix+'Stroke'],strokeWidth:c[prefix+'StrokeWidth'],opacity:c[prefix+'Opacity']/100});
}
function TrendTooltip({active,payload,label,c,unit}){
 if(!active||!payload?.length||!c.tooltip)return null;
 return h('div',{dangerouslySetInnerHTML:{__html:tooltipHtml(c,label,c.title.replace(/趋势图?$/,'')||c.title,payload[0].value,unit)}});
}
function Trend({c,data,unit,previewIndex=null}){
  const R=Recharts,Chart=c.type==='line'?R.LineChart:R.AreaChart,Series=c.type==='line'?R.Line:R.Area;
  const uid=React.useId().replace(/:/g,''),visible=data.slice(-c.period);
  const format=value=>formatYAxisValue(value,c,unit),yAxis=yAxisLayout(c,visible,unit);
  const dash={solid:undefined,dashed:'6 4',dotted:'2 3'};
  const yDomain=[yAxis.min,yAxis.max];
  const index=previewIndex===null?undefined:Math.min(visible.length-1,previewIndex);
  return h(R.ResponsiveContainer,{width:'100%',height:'100%'},h(Chart,{key:index===undefined?'interactive':'preview-'+index,data:visible,margin:{top:c.marginTop,right:c.marginRight,left:c.marginLeft,bottom:c.marginBottom},accessibilityLayer:true},
    h('defs',null,h('linearGradient',{id:uid,x1:0,y1:0,x2:0,y2:1},h('stop',{offset:'0%',stopColor:c.fillTop,stopOpacity:c.opacity/100}),h('stop',{offset:'100%',stopColor:c.fillBottom,stopOpacity:c.fillEndOpacity/100}))),
    c.grid&&h(R.CartesianGrid,{stroke:c.gridColor,strokeWidth:c.gridWidth,strokeDasharray:dash[c.gridDash],vertical:c.gridVertical,horizontal:c.gridHorizontal,opacity:c.gridOpacity/100}),
    h(R.XAxis,{hide:!c.xShow,dataKey:'name',height:c.xHeight,axisLine:c.xAxisLine?{stroke:c.axisColor}:false,tickLine:c.xTickLine?{stroke:c.axisColor}:false,interval:c.xInterval==='auto'?'preserveStartEnd':Number(c.xInterval),minTickGap:c.xGap,tickMargin:c.xTickMargin,padding:{left:c.xPadding,right:c.xPadding},tick:{fill:c.xColor,fontSize:c.xFont,angle:c.xAngle}}),
    h(R.YAxis,{hide:!c.yShow,width:yAxis.width,domain:yDomain,ticks:yAxis.ticks,tickCount:c.yTicks,allowDataOverflow:!c.yMaxAuto,axisLine:c.yAxisLine?{stroke:c.axisColor}:false,tickLine:c.yTickLine?{stroke:c.axisColor}:false,tickMargin:c.yTickMargin,tickFormatter:format,tick:{fill:c.yColor,fontSize:c.yFont}}),
    h(R.Tooltip,{defaultIndex:index,active:index!==undefined?true:undefined,isAnimationActive:false,offset:c.tooltipOffset,cursor:c.hoverLine&&index===undefined?{stroke:c.cursorColor,strokeWidth:c.cursorWidth,strokeDasharray:dash[c.cursorDash],opacity:c.cursorOpacity/100}:false,content:props=>h(TrendTooltip,{...props,c,unit})}),
    h(Series,{name:c.title,dataKey:'value',type:c.curve,stroke:c.colors[0],strokeWidth:c.width,strokeDasharray:dash[c.lineDash],strokeLinecap:c.lineCap,strokeLinejoin:'round',strokeOpacity:c.lineOpacity/100,fill:c.fillEnabled?'url(#'+uid+')':'none',fillOpacity:1,dot:c.dots?props=>h(TrendDot,{...props,c}):false,activeDot:c.hoverDot&&index===undefined?props=>h(TrendDot,{...props,c,active:true}):false,isAnimationActive:c.animation,animationDuration:c.animationDuration}),
    index!==undefined&&c.hoverLine&&h(R.ReferenceLine,{x:visible[index].name,stroke:c.cursorColor,strokeWidth:c.cursorWidth,strokeDasharray:dash[c.cursorDash],opacity:c.cursorOpacity/100,isFront:true}),
    index!==undefined&&c.hoverDot&&h(R.ReferenceDot,{x:visible[index].name,y:visible[index].value,isFront:true,shape:props=>h(TrendDot,{...props,c,active:true})})));
}
function TrendCard({c,data,unit,previewIndex=null}){
  return h('div',{className:'trend-card',style:{width:'100%',background:c.bg,borderRadius:10,padding:16,boxSizing:'border-box'}},
    h('div',{className:'trend-plot',style:{height:c.height,width:'100%',background:c.bg}},h(Trend,{c,data,unit,previewIndex})));
}
let chinaPromise=Promise.resolve(PORTABLE_CHINA_GEO);
function EChart({id,c,data,mobile,previewIndex=null}){const ref=useRef();const [error,setError]=useState('');useEffect(()=>{let disposed=false,chart,regionActions;setError('');function render(){const plotHeight=chartPlotHeight(id,c,data,mobile,ref.current.clientWidth);ref.current.style.height=plotHeight+'px';chart.resize({height:plotHeight});const option=optionFor(id,c,data,mobile,ref.current.clientWidth,regionActions);option.tooltip.alwaysShowContent=previewIndex!==null;if(previewIndex!==null){option.tooltip.triggerOn='none';if(option.tooltip.axisPointer)option.tooltip.axisPointer.status='show';}chart.setOption(option,true);regionActions?.restore();if(previewIndex!==null&&c.tooltip){const count=id==='gender'?2:id==='region'?Math.min(c.regionRankCount,data.length):data.length,index=Math.min(previewIndex,count-1);chart.dispatchAction({type:'showTip',seriesIndex:id==='gender'?index:0,dataIndex:id==='gender'?0:index});}}(async()=>{try{if(id==='region'){const geo=await chinaPromise;registerChinaMaps(geo);}if(disposed)return;chart=echarts.init(ref.current,null,{renderer:'svg'});if(id==='region')regionActions=createRegionActions(chart);render();}catch(e){console.error(e);setError(e.message)}})();const ob=new ResizeObserver(()=>{if(chart)render()});ob.observe(ref.current);return()=>{disposed=true;ob.disconnect();chart?.dispose()};},[id,c,data,mobile,previewIndex]);return h('div',null,error&&h('p',{role:'alert'},error),h('div',{ref,style:{height:c.height,width:'100%'}}));}
function sourceFor(id,c,data,mobile){
  if(['works','engagement','followers','article'].includes(id)){
    const unit=id==='article'?(metrics.find(x=>x[0]===c.metric)?.[2]||'次'):'次';
    return `import React from 'react';\nimport * as Recharts from 'recharts';\n// React 18.3.1 · Recharts 2.15.4\n// height 仅为绘图区高度；组件只包含图表，period 由外部传入。\nconst h = React.createElement;\nexport const DESIGN_TOKENS = ${JSON.stringify(DESIGN_TOKENS,null,2)};\n${chartToken.toString()}\n${escapeTooltip.toString()}\n${tooltipHtml.toString()}\n${formatYAxisValue.toString()}\n${yAxisLayout.toString()}\n${resolveChartTokens.toString()}\nexport const sharedAppearance = ${JSON.stringify(pickAppearance(c),null,2)};\nexport const sharedTooltip = ${JSON.stringify(pickTooltip(c),null,2)};\nconst chartConfig = ${JSON.stringify(c,null,2)};\nexport const config = {...chartConfig,...sharedAppearance,...sharedTooltip,tokenBindings:{...chartConfig.tokenBindings,...sharedAppearance.tokenBindings,...sharedTooltip.tokenBindings}};\nexport const data = ${JSON.stringify(data,null,2)};\n\n${TrendDot.toString()}\n\n${TrendTooltip.toString()}\n\n${Trend.toString()}\n\n${TrendCard.toString()}\n\nexport default function Chart({theme = config.tokenTheme, period = config.period} = {}) {\n  const themed = resolveChartTokens({...config,period},theme);\n  return h('div', { style: { width: ${c.widthMode==='fill'?"'100%'":c.cardWidth} } }, h(TrendCard, { c: themed, data, unit: ${JSON.stringify(unit)} }));\n}\n`;
  }
  return `import * as echarts from 'echarts';
// ECharts 5.6.0
${id==='region'?'// data 保留原始数值；显示值按全部地区合计换算百分比，隐藏排名项仍计入分母。\n':''}${id==='region'?"import china from './china.json';\n":''}export const DESIGN_TOKENS = ${JSON.stringify(DESIGN_TOKENS,null,2)};
${chartToken.toString()}
${escapeTooltip.toString()}
${tooltipHtml.toString()}
${formatYAxisValue.toString()}
${yAxisLayout.toString()}
${resolveChartTokens.toString()}
const GENDER_SVGS = ${JSON.stringify(GENDER_SVGS)};
${genderIcon.toString()}
${tintColor.toString()}
${shortProvince.toString()}
const MAP_LABEL_ANCHORS=${JSON.stringify(MAP_LABEL_ANCHORS)};
${mapLabelLayout.toString()}
${prepareChinaMap.toString()}
${clipMapRing.toString()}
${prepareSouthChinaMap.toString()}
const CHINA_MAP_BOUNDS={};
${chinaMapBounds.toString()}
${fitChinaMap.toString()}
${chartPlotHeight.toString()}
${registerChinaMaps.toString()}
${id==='region'?'registerChinaMaps(china);':''}
${alphaColor.toString()}
${optionFor.toString()}
${createRegionActions.toString()}
export const sharedAppearance = ${JSON.stringify(pickAppearance(c),null,2)};\nexport const sharedTooltip = ${JSON.stringify(pickTooltip(c),null,2)};\nconst chartConfig = ${JSON.stringify(c,null,2)};\nexport const config = {...chartConfig,...sharedAppearance,...sharedTooltip,tokenBindings:{...chartConfig.tokenBindings,...sharedAppearance.tokenBindings,...sharedTooltip.tokenBindings}};
export const data = ${JSON.stringify(data,null,2)};
export function mountChart(element, theme = config.tokenTheme) {
  element.style.width = ${c.widthMode==='fill'?"'100%'":JSON.stringify(c.cardWidth+'px')};
  element.style.height = config.height + 'px';
  const chart = echarts.init(element, null, { renderer: 'svg' });
  const regionActions = ${id==='region'?'createRegionActions(chart)':'null'};
  function render(){element.style.height=chartPlotHeight(${JSON.stringify(id)},config,data,${mobile},element.clientWidth)+'px';chart.resize(); chart.setOption(optionFor(${JSON.stringify(id)},resolveChartTokens(config,theme),data,${mobile},element.clientWidth,regionActions),true);regionActions?.restore(); }
  render();
  const observer = new ResizeObserver(render);
  observer.observe(element);
  return () => { observer.disconnect(); chart.dispose(); };
}`;
}
const controlGroups=[
['size','尺寸与留白',[
 ['n','绘图区高度','height',80,800,1,'px'],['s','卡片宽度模式','widthMode',[['fixed','输入宽度'],['fill','填满可用宽度']]],['n','卡片宽度','cardWidth',240,1800,1,'px'],
 ['n','绘图区上边距','marginTop',0,60,1,'px'],['n','绘图区右边距','marginRight',0,60,1,'px'],['n','绘图区下边距','marginBottom',0,60,1,'px'],['n','绘图区左边距','marginLeft',0,60,1,'px']]],
['line','曲线与面积填充',[
 ['s','图表类型','type',[['area','面积图'],['line','折线图']]],['s','曲线插值','curve',[['monotone','平滑曲线'],['linear','直线连接'],['step','阶梯线'],['stepBefore','前置阶梯'],['stepAfter','后置阶梯'],['natural','自然曲线'],['basis','B 样条']]],
 ['color','曲线颜色','lineColor'],['n','曲线粗细','width',0,8,.5,'px'],['s','曲线线型','lineDash',[['solid','实线'],['dashed','虚线'],['dotted','点线']]],['s','线端样式','lineCap',[['round','圆头'],['butt','平头'],['square','方头']]],['n','曲线不透明度','lineOpacity',0,100,1,'%'],
 ['b','显示面积填充','fillEnabled'],['color','渐变起始颜色','fillTop'],['n','渐变起始不透明度','opacity',0,100,1,'%'],['color','渐变结束颜色','fillBottom'],['n','渐变结束不透明度','fillEndOpacity',0,100,1,'%'],['color','绘图区背景','bg']]],
['dots','常态数据点',[
 ['b','显示常态数据点','dots'],['s','常态点形状','dotShape',[['circle','圆形'],['square','方形'],['diamond','菱形'],['triangle','三角形']]],['n','常态点半径','dotRadius',1,12,.5,'px'],['color','常态点填充色','dotFill'],['color','常态点描边色','dotStroke'],['n','常态点描边宽度','dotStrokeWidth',0,6,.5,'px'],['n','常态点不透明度','dotOpacity',0,100,1,'%']]],
['hover-dot','悬浮数据点',[
 ['b','显示悬浮数据点','hoverDot'],['s','悬浮点形状','activeShape',[['circle','圆形'],['square','方形'],['diamond','菱形'],['triangle','三角形']]],['n','悬浮点半径','activeRadius',1,16,.5,'px'],['color','悬浮点填充色','activeFill'],['color','悬浮点描边色','activeStroke'],['n','悬浮点描边宽度','activeStrokeWidth',0,8,.5,'px'],['n','悬浮点不透明度','activeOpacity',0,100,1,'%']]],
['hover-line','悬浮指示线',[
 ['b','显示悬浮指示线','hoverLine'],['color','悬浮线颜色','cursorColor'],['n','悬浮线宽度','cursorWidth',.5,6,.5,'px'],['s','悬浮线线型','cursorDash',[['solid','实线'],['dashed','虚线'],['dotted','点线']]],['n','悬浮线不透明度','cursorOpacity',0,100,1,'%']]],
['tooltip','悬浮提示框',[
 ['b','显示提示框','tooltip'],['color','提示框背景','tooltipBg'],['color','提示框边框色','tooltipBorder'],['n','提示框边框宽度','tooltipBorderWidth',0,4,.5,'px'],['n','提示框圆角','tooltipRadius',0,24,1,'px'],['n','提示框内边距','tooltipPadding',4,24,1,'px'],['n','提示框偏移','tooltipOffset',0,40,1,'px'],['b','提示框阴影','tooltipShadow'],['b','提示框显示日期／分组','tooltipDate'],['b','提示框显示指标名称','tooltipName'],['b','提示框显示单位','tooltipUnit'],['color','提示框辅助文字颜色','tooltipLabelColor'],['n','提示框辅助文字字号','tooltipLabelSize',9,20,1,'px'],['color','提示框数值颜色','tooltipText'],['n','提示框数值字号','tooltipFont',9,24,1,'px'],['b','提示框数值加粗','tooltipBold'],['color','提示框名称颜色','tooltipNameColor'],['n','提示框最小宽度','tooltipMinWidth',100,280,1,'px'],['n','提示框名称与数值间距','tooltipGap',8,48,1,'px']]],
['axes','坐标轴与刻度',[
 ['b','显示 X 轴','xShow'],['color','X 轴文字颜色','xColor'],['n','X 轴字号','xFont',8,20,1,'px'],['n','X 轴文字角度','xAngle',-60,60,5,'°'],['n','X 轴区域高度','xHeight',16,60,1,'px'],['n','X 轴标签间距','xGap',0,100,1,'px'],['n','X 轴标签偏移','xTickMargin',0,20,1,'px'],['n','X 轴两端留白','xPadding',0,30,1,'px'],['s','X 轴标签间隔','xInterval',[['auto','自动避让'],['0','每个日期'],['1','隔 1 个日期'],['2','隔 2 个日期']]],['b','显示 X 轴轴线','xAxisLine'],['b','显示 X 轴刻度线','xTickLine'],
 ['b','显示 Y 轴','yShow'],['color','Y 轴文字颜色','yColor'],['n','Y 轴字号','yFont',8,20,1,'px'],['b','Y 轴宽度自动适应数字','yAutoWidth'],['n','Y 轴手动宽度','yWidth',20,200,1,'px'],['n','Y 轴标签偏移','yTickMargin',0,20,1,'px'],['n','Y 轴刻度数量','yTicks',2,10,1,'个'],['s','Y 轴数字格式','yFormat',[['compact','缩写（1K）'],['raw','原始数值'],['percent','百分比']]],['n','缩写保留小数位','yDecimals',0,3,1,'位'],['n','Y 轴最小值','yMin',0,1000000,1,''],['b','自动计算 Y 轴最大值','yMaxAuto'],['n','Y 轴最大值','yMax',1,10000000,1,''],['b','显示 Y 轴轴线','yAxisLine'],['b','显示 Y 轴刻度线','yTickLine'],['color','轴线与刻度线颜色','axisColor']]],
['grid','网格与动画',[
 ['b','显示网格','grid'],['b','显示横向网格','gridHorizontal'],['b','显示纵向网格','gridVertical'],['color','网格颜色','gridColor'],['n','网格线宽度','gridWidth',.5,3,.5,'px'],['s','网格线型','gridDash',[['solid','实线'],['dashed','虚线'],['dotted','点线']]],['n','网格不透明度','gridOpacity',0,100,1,'%'],['b','开启动画','animation'],['n','动画时长','animationDuration',0,2000,50,'ms']]]
];
function NumberField({label,value,min,max,step=1,unit,onChange}){
  const [draft,setDraft]=React.useState(String(value));
  React.useEffect(()=>setDraft(String(value)),[value]);
  function change(text){setDraft(text);if(text.trim()!==''&&Number.isFinite(+text)&&+text>=min&&+text<=max)onChange(+text)}
  function commit(){const n=Number.isFinite(+draft)&&draft.trim()!==''?Math.max(min,Math.min(max,+draft)):value;onChange(n);setDraft(String(n))}
  return h('div',{className:'field number-field'},h('label',null,label,h('span',{className:'number-box'},h('input',{'aria-label':label+'数值',type:'number',min,max,step,value:draft,onChange:e=>change(e.target.value),onBlur:commit,onKeyDown:e=>{if(e.key==='Enter')e.target.blur()}}),unit&&h('small',null,unit))),max<=2000&&h('input',{'aria-label':label,type:'range',min,max,step,value,onChange:e=>onChange(+e.target.value)}));
}

function appendTooltipToSvg(svg,tooltip,plotRect){
 if(!tooltip||getComputedStyle(tooltip).visibility==='hidden')return;
 const ns='http://www.w3.org/2000/svg',r=tooltip.getBoundingClientRect(),style=getComputedStyle(tooltip);
 const create=(tag,attrs)=>{const e=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);return e};
 const group=create('g',{'data-export-tooltip':'true'});
 const shadow=style.boxShadow!=='none';
 if(shadow){const filter=create('filter',{id:'export-tooltip-shadow',x:'-40%',y:'-50%',width:'180%',height:'220%'});filter.appendChild(create('feDropShadow',{dx:0,dy:4,stdDeviation:5,'flood-color':DESIGN_TOKENS.light.MapUIFrame01A,'flood-opacity':.12}));svg.appendChild(filter);}
 const box=create('rect',{x:r.left-plotRect.left,y:r.top-plotRect.top,width:r.width,height:r.height,rx:parseFloat(style.borderRadius)||0,fill:style.backgroundColor,stroke:style.borderColor,'stroke-width':parseFloat(style.borderWidth)||0});if(shadow)box.setAttribute('filter','url(#export-tooltip-shadow)');group.appendChild(box);
 for(const el of tooltip.querySelectorAll('.tooltip-data-date,.tooltip-data-name,.tooltip-data-value')){
  const rect=el.getBoundingClientRect(),css=getComputedStyle(el),right=el.classList.contains('tooltip-data-value');
  const text=create('text',{x:(right?rect.right:rect.left)-plotRect.left,y:rect.top-plotRect.top,'dominant-baseline':'text-before-edge','text-anchor':right?'end':'start',fill:css.color,'font-family':css.fontFamily,'font-size':parseFloat(css.fontSize),'font-weight':css.fontWeight});text.textContent=el.textContent;group.appendChild(text);
 }
 svg.appendChild(group);
}

function download(name,text,type='application/json'){const u=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);}
function App(){const [id,setId]=useState('gender'),[device,setDevice]=useState('mobile'),[tab,setTab]=useState('code'),[toast,setToast]=useState(''),[modal,setModal]=useState(null),[draft,setDraft]=useState(''),[error,setError]=useState(''),[hoverPreview,setHoverPreview]=useState(false),[hoverIndex,setHoverIndex]=useState(2),[exporting,setExporting]=useState(false),[imageFormat,setImageFormat]=useState('svg'),[theme,setTheme]=useState(()=>{try{return (localStorage.getItem('zhihu-chart-portable-theme-02d91b291f8e')||PORTABLE_PRESET.theme)==='dark'?'dark':'light'}catch{return PORTABLE_PRESET.theme||'light'}});const dlg=useRef(),file=useRef();const [saved,setSaved]=useState(()=>{try{return JSON.parse(localStorage.getItem('zhihu-chart-portable-02d91b291f8e'))||PORTABLE_PRESET}catch{return PORTABLE_PRESET}});const key=id+'-'+device,raw=applySharedAppearance(applySharedTooltip(normalizeConfig(saved.configs[key],device,id),getSharedTooltip(saved)),getSharedAppearance(saved)),mobile=device==='mobile',item=charts.find(x=>x[0]===id),isTrend=item[3]==='Recharts';
const metric=metrics.find(x=>x[0]===raw.metric)||metrics[0];
const c=resolveChartTokens({...raw,title:raw.title||(id==='article'?metric[1]+'趋势图':item[1])},theme);
const dataKey=id==='article'?'article-'+c.metric:id+'-'+c.distributionMetric;
const data=isTrend?(saved.data[dataKey]||saved.data[id]||defaults[id]).map(d=>({name:d.name,value:saved.data[dataKey]?d.value:(metric[2]==='%'?Math.round(d.value*metric[3]*100)/100:Math.round(d.value*metric[3]))})):(saved.data[dataKey]||(c.distributionMetric==='readers'?saved.data[id]:null)||distributionSample(id,c.distributionMetric)).map(d=>({...d}));
const code=sourceFor(id,c,data,mobile);
useEffect(()=>{const header=document.querySelector('header');const observer=new ResizeObserver(()=>document.documentElement.style.setProperty('--app-header-height',header.offsetHeight+'px'));observer.observe(header);return()=>observer.disconnect()},[]);
useEffect(()=>{document.documentElement.dataset.theme=theme;try{localStorage.setItem('zhihu-chart-portable-theme-02d91b291f8e',theme)}catch{}},[theme]);
useEffect(()=>{try{localStorage.setItem('zhihu-chart-portable-02d91b291f8e',JSON.stringify(saved))}catch{tell('浏览器存储不可用，请导出配置备份')}},[saved]);useEffect(()=>{if(modal)dlg.current?.showModal();},[modal]);function tell(t){setToast(t);setTimeout(()=>setToast(''),3000)}function update(p){setSaved(s=>{const shared=getSharedTooltip(s),appearance=getSharedAppearance(s);for(const k of TOOLTIP_KEYS)if(p[k]!==undefined)shared[k]=p[k];for(const k of APPEARANCE_KEYS)if(p[k]!==undefined)appearance[k]=p[k];if(p.tokenBindings){for(const k of TOOLTIP_KEYS)if(p.tokenBindings[k])shared.tokenBindings[k]=p.tokenBindings[k];for(const k of APPEARANCE_KEYS)if(p.tokenBindings[k])appearance.tokenBindings[k]=p.tokenBindings[k];}return {...s,sharedTooltip:shared,sharedAppearance:appearance,configs:{...s.configs,[key]:{...normalizeConfig(s.configs[key],device,id),...p}}}})}function resetCurrent(){setSaved(s=>({...s,configs:{...s.configs,[key]:normalizeConfig({},device,id)}}))}function resetGlobalAppearance(){setSaved(s=>({...s,sharedAppearance:pickAppearance(initial)}))}function resetGlobalTooltip(){setSaved(s=>({...s,sharedTooltip:pickTooltip(initial)}))}function close(){dlg.current.close();setModal(null);setError('')}async function copy(){try{await navigator.clipboard.writeText(code);tell('已复制当前图表代码')}catch{setDraft(code);setModal('copy')}}
function range(label,name,min,max,unit='px'){return h(NumberField,{key:name,label,value:c[name],min,max,unit,step:['mapStrokeWidth','mapHoverStrokeWidth','mapBoundaryWidth','islandStrokeWidth','islandHoverStrokeWidth','insetFrameWidth'].includes(name)?.1:1,onChange:v=>update({[name]:v})})}
function toggle(label,name){return h('label',{className:'toggle'},label,h('input',{type:'checkbox',checked:c[name],onChange:e=>update({[name]:e.target.checked})}))}
function color(label,name){
 const field=name==='lineColor'?'series0':name,token=c.tokenBindings[field],value=field.startsWith('series')?c.colors[Number(field.slice(6))]:c[name];
 const groups=[...new Set(Object.values(TOKEN_META).map(v=>v.group))];
 return h('div',{className:'field token-field'},h('label',null,label),h('div',{className:'token-control'},h('span',{className:'token-swatch',style:{background:value},'aria-hidden':true}),h(Select,{'aria-label':label+' token',value:token,tokenColors:DESIGN_TOKENS[theme],onChange:e=>update({tokenBindings:{...raw.tokenBindings,[field]:e.target.value}})},groups.map(group=>h('optgroup',{key:group,label:group},Object.entries(TOKEN_META).filter(([,v])=>v.group===group).map(([name,meta])=>h('option',{key:name,value:name},name)))))),h('small',{className:'token-description'},TOKEN_META[token]?.label.split(' ')[0]+' · '+value));
}
function control(f){const [type,label,name,min,max,step,unit]=f;
 if(name==='yWidth'&&c.yAutoWidth)return null;
 if(type==='n')return h(NumberField,{key:name,label,value:c[name],min,max,step,unit,onChange:v=>update({[name]:v})});
 if(type==='b')return h(React.Fragment,{key:name},toggle(label,name));
 if(type==='s')return h('div',{className:'field',key:name},h('label',null,label),h(Select,{'aria-label':label,value:c[name],onChange:e=>update({[name]:e.target.value})},min.map(([value,text])=>h('option',{key:value,value},text))));
 return h(React.Fragment,{key:name},color(label,name));
}
function openData(){setDraft(JSON.stringify(data,null,2));setModal('data')}
async function saveImage(){
 if(exporting)return;setExporting(true);
 try{
  await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  const node=document.querySelector(isTrend?'.trend-plot svg.recharts-surface':'.preview svg');
  if(!node)throw Error('图表尚未完成渲染，请稍后重试');
  const rect=node.getBoundingClientRect(),w=Math.round(rect.width),height=Math.round(rect.height);
  if(!w||!height)throw Error('图表尺寸无效');
  const svg=node.cloneNode(true);svg.setAttribute('xmlns','http://www.w3.org/2000/svg');svg.setAttribute('width',w);svg.setAttribute('height',height);svg.setAttribute('viewBox',`0 0 ${w} ${height}`);svg.style.fontFamily=getComputedStyle(node).fontFamily;
  const background=document.createElementNS('http://www.w3.org/2000/svg','rect');background.setAttribute('width',w);background.setAttribute('height',height);background.setAttribute('fill',c.bg);svg.insertBefore(background,svg.firstChild);
  appendTooltipToSvg(svg,document.querySelector('.preview .studio-tooltip'),rect);
  const xml=new XMLSerializer().serializeToString(svg),name=dataKey+'-'+device+'-'+theme+'-'+w+'x'+height;
  if(imageFormat==='svg'){download(name+'.svg',xml,'image/svg+xml;charset=utf-8');}
  else{
   const url=URL.createObjectURL(new Blob([xml],{type:'image/svg+xml;charset=utf-8'}));
   try{const img=new Image();await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(Error('图片生成失败'));img.src=url});const canvas=document.createElement('canvas');canvas.width=w*2;canvas.height=height*2;canvas.getContext('2d').drawImage(img,0,0,w*2,height*2);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('PNG 生成失败');const link=document.createElement('a'),out=URL.createObjectURL(blob);link.href=out;link.download=name+'@2x.png';link.click();setTimeout(()=>URL.revokeObjectURL(out),1000);}finally{URL.revokeObjectURL(url)}
  }
  tell(isTrend?'已下载图表，包含当前悬浮框、悬浮点与指示线':'已下载当前图表');
 }catch(e){tell(e.message)}finally{setExporting(false)}
}
function validateData(d,chartId){if(!Array.isArray(d)||d.length<2||d.length>100)throw Error('请输入 2–100 项数据数组');if(d.some(x=>typeof x.name!=='string'||!Number.isFinite(x.value)||x.value<0))throw Error('每项需包含 name（日期）和非负 value（数值）');if(chartId==='gender'&&(d.length!==2||d[0].value+d[1].value<=0))throw Error('性别数据需为两项人数，合计大于 0');return d;}
function importConfig(e){const f=e.target.files[0];if(!f)return;f.text().then(t=>{try{
 const x=JSON.parse(t);if(x.schema!=='zhihu-chart-studio/1'||!x.configs||!x.data)throw Error('请选择本工作台导出的配置文件');
 for(const [k,v] of Object.entries(x.data)){if(!validDataKey(k))throw Error('未知图表');validateData(v,k.split('-')[0])}
 const clean={};for(const [k,v] of Object.entries(x.configs)){
  if(!charts.some(([id])=>k===id+'-pc'||k===id+'-mobile')&&!legacyChartIds.some(id=>k===id+'-pc'||k===id+'-mobile'))throw Error('未知配置');
  const z=normalizeConfig(v,k.endsWith('-pc')?'pc':'mobile',k.replace(/-(pc|mobile)$/,''));
  for(const p in initial){if(p==='colors'){if(!Array.isArray(z.colors)||z.colors.length!==8||z.colors.some(s=>!/^#[0-9a-f]{6}$/i.test(s)))throw Error('无效配色');}else if(typeof z[p]!==typeof initial[p])throw Error('无效参数 '+p);}
  for(const [,,fields] of controlGroups)for(const f of fields){const [type,label,name,min,max]=f;const value=name==='lineColor'?z.colors[0]:z[name];if(type==='n'&&(!Number.isFinite(value)||value<min||value>max))throw Error(label+'超出范围');if(type==='s'&&!min.some(x=>x[0]===value))throw Error(label+'无效');if(type==='color'&&!/^#[0-9a-f]{6}$/i.test(value))throw Error(label+'无效');}
  if(distributionMetrics[k.replace(/-(pc|mobile)$/,'')]&&!distributionMetrics[k.replace(/-(pc|mobile)$/,'')].some(m=>m[0]===z.distributionMetric))throw Error('无效数据指标');
  if(![7,14,30].includes(z.period)||!metrics.some(m=>m[0]===z.metric))throw Error('无效日期范围或指标');clean[k]=z;
 }
 if(x.sharedTooltip){const shared=x.sharedTooltip;for(const f of controlGroups.find(g=>g[0]==='tooltip')[2]){const [type,label,name,min,max]=f;if(typeof shared[name]!==typeof initial[name]||type==='n'&&(!Number.isFinite(shared[name])||shared[name]<min||shared[name]>max)||type==='color'&&!/^#[0-9a-f]{6}$/i.test(shared[name]))throw Error('无效全局提示样式：'+label)}for(const [field,name] of Object.entries(shared.tokenBindings||{}))if(!TOOLTIP_KEYS.includes(field)||!DESIGN_TOKENS.light[name])throw Error('无效提示框 Token');}
 if(x.sharedAppearance){if(x.sharedAppearance.yAutoWidth===undefined)x.sharedAppearance.yAutoWidth=true;for(const key of APPEARANCE_KEYS){const value=x.sharedAppearance[key];if(typeof value!==typeof initial[key]||typeof value==='number'&&!Number.isFinite(value))throw Error('无效全局样式：'+key)}for(const [field,name] of Object.entries(x.sharedAppearance.tokenBindings||{}))if(!APPEARANCE_KEYS.includes(field)||!DESIGN_TOKENS.light[name])throw Error('无效全局样式 Token');for(const [,,fields] of controlGroups)for(const [type,label,name,min,max] of fields)if(APPEARANCE_KEYS.includes(name)){const value=x.sharedAppearance[name];if(type==='n'&&(value<min||value>max)||type==='s'&&!min.some(v=>v[0]===value)||type==='color'&&!/^#[0-9a-f]{6}$/i.test(value))throw Error('无效全局样式：'+label)}}
 setSaved({configs:clean,data:x.data,sharedTooltip:x.sharedTooltip||getSharedTooltip({configs:clean}),sharedAppearance:x.sharedAppearance||getSharedAppearance({configs:clean})});if(['light','dark'].includes(x.theme))setTheme(x.theme);tell('配置已导入');
 }catch(err){tell(err.message)}});e.target.value='';}
async function exportAll(){const publicData=Object.fromEntries(Object.entries({...defaults,...Object.fromEntries(Object.entries(distributionMetrics).flatMap(([id,list])=>list.map(m=>[id+'-'+m[0],saved.data[id+'-'+m[0]]||(m[0]==='readers'?saved.data[id]:null)||distributionSample(id,m[0])]))),...saved.data}).filter(([key])=>validDataKey(key)&&!legacyChartIds.includes(key)));const configs={};charts.forEach(([id])=>['pc','mobile'].forEach(d=>configs[id+'-'+d]=resolveChartTokens(applySharedAppearance(applySharedTooltip(normalizeConfig(saved.configs[id+'-'+d],d,id),getSharedTooltip(saved)),getSharedAppearance(saved)),theme)));const bundle={schema:'zhihu-chart-studio/1',theme,sharedTooltip:getSharedTooltip(saved),sharedAppearance:getSharedAppearance(saved),designTokens:DESIGN_TOKENS,tokenMetadata:TOKEN_META,figma:{fileKey:'sWhGJbvGtUe0D0JIia4du5',lightNode:'354:524',darkNode:'354:655'},libraries:{react:'18.3.1',recharts:'2.15.4',echarts:'5.6.0'},configs,data:publicData};download('zhihu-chart-config.json',JSON.stringify(bundle,null,2));tell('已导出全部图表与双端配置')}
return h(React.Fragment,null,h('header',null,h('div',{className:'brand'},'创中图表样式工作台'),h('div',{className:'grow'}),h('span',{className:'save'},icon('check-circle'),'自动保存于本机'),h('label',{className:'theme-switch'},icon(theme==='light'?'sun':'moon'),h(Select,{'aria-label':'颜色主题',value:theme,onChange:e=>setTheme(e.target.value)},h('option',{value:'light'},'浅色'),h('option',{value:'dark'},'深色'))),h('button',{onClick:()=>file.current.click()},icon('upload-simple'),'导入配置'),h('button',{className:'primary',onClick:exportAll},icon('download-simple'),'导出全部配置'),h('input',{ref:file,type:'file',accept:'.json',hidden:true,onChange:importConfig})),h('div',{className:'layout'},h('aside',null,h('div',{className:'group'},'图形类型',h('span',null,'5 类')),charts.map(([cid,title,icon,lib],i)=>h(React.Fragment,{key:cid},h('button',{className:'nav '+(id===cid?'active':''),onClick:()=>setId(cid)},h('span',{className:'ico'},h(Icon,{name:icon})),title))),h('div',{className:'aside-foot'},'基于官方开源组件',h('br'),h('a',{href:'https://recharts.github.io/',target:'_blank',rel:'noreferrer'},'Recharts 2.15.4 ',icon('arrow-up-right')),h('br'),h('a',{href:'https://echarts.apache.org/zh/index.html',target:'_blank',rel:'noreferrer'},'ECharts 5.6.0 ',icon('arrow-up-right')))),h('main',{className:'main'},h('div',{className:'heading'},h('h1',null,item[1])),h('div',{className:'toolbar'},h('div',{className:'seg'},h('button',{className:!mobile?'active':'',onClick:()=>setDevice('pc')},icon('desktop'),'PC 端'),h('button',{className:mobile?'active':'',onClick:()=>setDevice('mobile')},icon('device-mobile'),'移动端')),h('div',{className:'grow'}),id==='article'&&h(Select,{'aria-label':'趋势指标',className:'metric-select',value:c.metric,onChange:e=>update({metric:e.target.value,title:''})},metrics.map(m=>h('option',{key:m[0],value:m[0]},m[1]))),!isTrend&&h(Select,{'aria-label':'数据指标',className:'metric-select',value:c.distributionMetric,onChange:e=>update({distributionMetric:e.target.value})},distributionMetrics[id].map(m=>h('option',{key:m[0],value:m[0]},m[1]))),h('button',{onClick:openData,style:{fontSize:11}},icon('table'),'编辑示例数据'),h(Select,{'aria-label':'图片格式',className:'image-format',value:imageFormat,onChange:e=>setImageFormat(e.target.value)},h('option',{value:'png'},'PNG · 2×'),h('option',{value:'svg'},'SVG')),h('button',{onClick:saveImage,disabled:exporting,className:'image-download'},icon('image'),'下载图片')),isTrend&&h('div',{className:'range-toolbar'},h('span',null,'时间范围'),h('div',{className:'range-switch',role:'group','aria-label':'趋势时间范围'},[7,14,30].map(n=>h('button',{key:n,type:'button',className:c.period===n?'active':'','aria-pressed':c.period===n,onClick:()=>update({period:n})},'近 '+n+' 日')))),h('div',{className:'canvas'},h('div',{className:'preview '+(mobile?'mobile':''),style:{background:c.bg,borderRadius:10,padding:0,width:c.widthMode==='fill'?'100%':c.cardWidth,maxWidth:'none',flexShrink:0}},isTrend?h(TrendCard,{c:exporting?{...c,animation:false}:c,data,unit:id==='article'?metric[2]:'次',previewIndex:hoverPreview?hoverIndex:null}):h('div',{className:'chart',style:{padding:16}},h(EChart,{id,c,data,mobile,previewIndex:hoverPreview?hoverIndex:null})))),h('div',{className:'details'},h('div',{className:'tabs'},h('button',{className:tab==='code'?'active':'',onClick:()=>setTab('code')},icon('code'),'组件代码'),h('button',{className:tab==='spec'?'active':'',onClick:()=>setTab('spec')},'交付说明'),h('button',{className:tab==='tokens'?'active':'',onClick:()=>setTab('tokens')},'颜色 Token'),h('div',{className:'grow'}),h('button',{onClick:copy},icon('copy'),'复制代码'),h('button',{onClick:()=>{download(id+'-'+device+(isTrend?'.jsx':'.js'),code,'text/javascript');tell('已下载当前代码')}},icon('download-simple'),'下载')),tab==='code'?h('pre',{className:'code'},code):tab==='tokens'?h('div',{className:'token-browser'},h('div',{className:'token-browser-heading'},h('span',null,(theme==='light'?'浅色':'深色')+'色板 · 53 个 Figma Token'),h('button',{onClick:()=>download('figma-color-tokens.json',JSON.stringify({tokens:DESIGN_TOKENS,metadata:TOKEN_META},null,2))},icon('download-simple'),'下载 Token')),h('div',{className:'token-grid'},Object.entries(TOKEN_META).map(([name,meta])=>h('div',{className:'token-card',key:name,title:meta.label},h('div',{className:'token-chip',style:{background:DESIGN_TOKENS[theme][name]}}),h('code',null,name),h('small',null,DESIGN_TOKENS[theme][name]))))):h('div',{className:'note'},'1. 全局图表样式与全局悬浮提示框一次修改、同步全部图表与双端，导出配置中的 sharedAppearance / sharedTooltip 为共用样式。',h('br'),'2. 当前图表的尺寸、曲线、柱条、数据与刻度范围独立保存。时间范围和数据指标在图表外部切换。',h('br'),'3. 各图表均可固定悬浮预览，导出图片包含当前提示框。导出全部配置后可交给开发，或导入另一台设备继续调整。',h('br'),'4. 界面图标使用 Phosphor 官方素材。地域图另需 china.json。性别使用提供的 SVG，颜色绑定各自圆环 Token。地域地图、排名和悬浮提示按全部地区合计显示百分比；默认排名显示五个地区。',h('br'),h('button',{onClick:()=>{chinaPromise.then(g=>download('china.json',JSON.stringify(g))).catch(()=>tell('地图下载失败'))}},'下载中国地图数据')))),h('section',{className:'panel'},h('div',{className:'panel-title'},'图表样式',h('button',{onClick:resetCurrent},icon('arrow-counter-clockwise'),'重置')),
h('h3',{className:'style-scope-title'},'全局样式'),
h('details',{className:'control-group global-appearance-group',open:false},h('summary',null,'全局图表样式',h('small',null,'背景 · 坐标轴 · 网格')),h('p',{className:'panel-note'},'背景同步五类图表；坐标轴、网格线和参考线同步趋势图与年龄柱状图。PC／移动端共用。'),h('details',{className:'control-group'},h('summary',null,'背景与绘图区留白'),h('div',{className:'control-fields'},[['color','图表背景','bg'],...controlGroups.find(g=>g[0]==='size')[2].filter(f=>f[2].startsWith('margin'))].map(control))),h('details',{className:'control-group'},h('summary',null,'横纵坐标样式'),h('div',{className:'control-fields'},controlGroups.find(g=>g[0]==='axes')[2].filter(f=>APPEARANCE_KEYS.includes(f[2])).map(control))),h('details',{className:'control-group'},h('summary',null,'网格线样式'),h('div',{className:'control-fields'},controlGroups.find(g=>g[0]==='grid')[2].filter(f=>APPEARANCE_KEYS.includes(f[2])).map(control))),h('details',{className:'control-group'},h('summary',null,'悬浮参考线样式'),h('div',{className:'control-fields'},controlGroups.find(g=>g[0]==='hover-line')[2].map(control))),h('button',{className:'tooltip-reset',onClick:resetGlobalAppearance},icon('arrow-counter-clockwise'),'重置全局图表样式')),
h('details',{className:'control-group global-tooltip-group',open:false},h('summary',null,'全局悬浮提示框',h('small',null,'5 类 · 双端共用')),h('p',{className:'panel-note'},'修改一次，同步全部图表；明暗主题继续使用颜色 Token。'),h('div',{className:'tooltip-style-sample',dangerouslySetInnerHTML:{__html:tooltipHtml(c,'11-26 / 数据分组','指标名称',3800,'人')}}),h('details',{className:'control-group'},h('summary',null,'外观与间距'),h('div',{className:'control-fields'},controlGroups.find(g=>g[0]==='tooltip')[2].filter(f=>['tooltip','tooltipBg','tooltipBorder','tooltipBorderWidth','tooltipRadius','tooltipPadding','tooltipOffset','tooltipShadow','tooltipMinWidth','tooltipGap'].includes(f[2])).map(control))),h('details',{className:'control-group'},h('summary',null,'文字与内容'),h('div',{className:'control-fields'},controlGroups.find(g=>g[0]==='tooltip')[2].filter(f=>!['tooltip','tooltipBg','tooltipBorder','tooltipBorderWidth','tooltipRadius','tooltipPadding','tooltipOffset','tooltipShadow','tooltipMinWidth','tooltipGap'].includes(f[2])).map(control))),h('button',{className:'tooltip-reset',onClick:resetGlobalTooltip},icon('arrow-counter-clockwise'),'重置全局提示样式')),
h('div',{className:'hover-preview-box'},h('label',{className:'toggle'},'固定悬浮预览',h('input',{type:'checkbox',checked:hoverPreview,onChange:e=>{setHoverPreview(e.target.checked);if(e.target.checked&&isTrend)update({hoverDot:true})}})),hoverPreview&&h('div',{className:'field'},h('label',null,'预览数据点'),h(Select,{'aria-label':'预览数据点',value:Math.min(hoverIndex,(isTrend?Math.min(c.period,data.length):id==='region'?Math.min(c.regionRankCount,data.length):data.length)-1),onChange:e=>setHoverIndex(+e.target.value)},(isTrend?data.slice(-c.period):id==='region'?[...data].sort((a,b)=>b.value-a.value).slice(0,c.regionRankCount):data).map((d,i)=>h('option',{key:i,value:i},d.name+' · '+d.value))))),
h('h3',{className:'style-scope-title chart-scope-title'},item[1]+'样式'),
isTrend?h(React.Fragment,null,
 h('p',{className:'panel-note'},'颜色绑定 Figma 语义 Token，明暗主题自动映射。尺寸仅调整绘图区，图表填满卡片内容区。'),
 controlGroups.filter(g=>g[0]!=='tooltip').map(([gid,title,fields])=>[gid,gid==='axes'?'当前指标刻度范围':gid==='grid'?'动画':title,fields.filter(f=>!APPEARANCE_KEYS.includes(f[2]))]).filter(g=>g[2].length).map(([gid,title,fields])=>h('details',{className:'control-group',key:gid,open:true},h('summary',null,title,h('small',null,fields.length+' 项')),h('div',{className:'control-fields'},fields.map(control)))))
 :h(React.Fragment,null,h('details',{className:'control-group',open:true},h('summary',null,'尺寸与颜色'),range('绘图区高度','height',80,800),control(['s','卡片宽度模式','widthMode',[['fixed','输入宽度'],['fill','填满可用宽度']]]),range('卡片宽度','cardWidth',240,1800),color('标签颜色','text'),id==='traffic'?h(React.Fragment,null,color('APP 蓝色','series0'),color('PC 蓝色','series4'),range('梯度起始不透明度','trafficGradientStart',0,100,'%'),range('梯度结束不透明度','trafficGradientEnd',0,100,'%')):h('div',null,c.colors.slice(0,id==='gender'?2:1).map((v,i)=>h(React.Fragment,{key:i},color(id==='region'?'地图主色':'系列颜色 '+(i+1),'series'+i)))),['traffic','gender'].includes(id)&&range('环形内径比例','inner',20,95,'%'),id==='age'&&range('柱条宽度','bar',8,40),id==='gender'&&range('色彩不透明度','seriesOpacity',10,100,'%'),id!=='region'&&range('圆角','radius',0,20),id!=='region'&&range('标签字号','font',9,18)),['traffic','region'].includes(id)&&h('details',{className:'control-group',open:true},h('summary',null,'图表布局'),control(['s','排版方式','distributionLayout',[['auto','自动（PC 左右 / 手机上下）'],['horizontal','左右排版'],['vertical','上下排版']]]),id==='region'&&range('左右区域间距','distributionGap',8,100),id==='region'&&range('左侧区域占比','distributionSplit',30,65,'%')),id==='gender'&&h('details',{className:'control-group',open:true},h('summary',null,'中心图标'),h('p',{className:'panel-note'},'使用提供的 SVG；颜色跟随各自圆环的颜色 Token。'),range('中心图标尺寸','genderIconSize',16,64),range('中心图标不透明度','genderIconOpacity',0,100,'%')),id==='traffic'&&h('details',{className:'control-group',open:true},h('summary',null,'环图与图例整体布局'),toggle('整体宽度填满卡片','trafficContentFill'),range('图表与图例整体宽度','trafficContentWidth',200,1800),control(['s','整体对齐方式','trafficContentAlign',[['center','居中'],['left','靠左'],['right','靠右']]]),range('环图与图例距离','trafficChartLegendGap',0,160),range('图例两列间距','trafficLegendGap',0,80),range('图例行间距','trafficLegendRowGap',4,30)),id==='region'&&h('details',{className:'control-group',open:true},h('summary',null,'地域排名柱状图'),h('p',{className:'panel-note'},'样式独立于地图；按全部地区合计计算百分比，数据与地图同步。'),h('button',{className:'tooltip-reset',onClick:openData},icon('table'),'编辑地域数据'),range('排名显示数量','regionRankCount',1,10,'项'),color('排名柱条颜色','regionBarColor'),range('排名柱条粗细','regionBarWidth',2,40),range('排名柱条圆角','regionBarRadius',0,20),range('排名柱条不透明度','regionBarOpacity',0,100,'%'),toggle('排名使用透明度梯度','regionRankGradient'),range('排名末项不透明度','regionRankEndOpacity',0,100,'%'),toggle('显示排名地区名称','regionRankShowNames'),color('排名地区名称颜色','regionRankNameColor'),range('排名地区名称字号','regionRankNameSize',8,20),toggle('显示排名数值','regionRankShowValues'),color('排名数值颜色','regionRankValueColor'),range('排名数值字号','regionRankValueSize',8,20),range('地域百分比小数位','regionPercentDecimals',0,3,'位'),toggle('排名柱条显示底轨','regionBarTrack'),color('排名底轨颜色','regionTrackColor')),id==='age'&&h('details',{className:'control-group',open:true},h('summary',null,'当前指标刻度范围'),controlGroups.find(g=>g[0]==='axes')[2].filter(f=>!APPEARANCE_KEYS.includes(f[2])).map(control)),id==='region'&&h('details',{className:'control-group',open:true},h('summary',null,'地图文字与九段线'),toggle('显示地图地名','labels'),range('地图文字字号','mapLabelSize',4,28),color('地图文字颜色','mapLabelColor'),control(['s','九段线显示模式','mapBoundaryMode',[['full','完整地图内'],['inset','右下角小图'],['hidden','隐藏九段线']]]),toggle('附图模式自动收紧高度','mapAutoHeight'),h('p',{className:'panel-note'},'开启后，附图模式高度按地图比例和排名行数计算；关闭后使用手动绘图区高度。')),id==='region'&&h('details',{className:'control-group',open:true},h('summary',null,'南海诸岛附图样式'),color('附图边框颜色','insetFrameColor'),range('附图边框粗细','insetFrameWidth',0,5),range('附图边框不透明度','insetFrameOpacity',0,100,'%'),control(['s','小岛屿显示方式','islandShapeMode',[['outline','真实轮廓'],['dots','简化为小圆点']]]),h('p',{className:'panel-note'},'仅简化南海小岛礁；大岛、海岸和九段线保留原形。相邻重叠的小点合并显示，数据与选择联动保持一致。'),color('附图岛屿描边颜色','islandStrokeColor'),range('附图岛屿描边粗细','islandStrokeWidth',0,5),range('附图岛屿描边不透明度','islandStrokeOpacity',0,100,'%'),color('附图岛屿悬浮描边颜色','islandHoverStrokeColor'),range('附图岛屿悬浮描边粗细','islandHoverStrokeWidth',0,8),h('p',{className:'panel-note'},'海南岛与归属海南的附图岛礁联动，使用同一份海南省数据；广东、台湾等定位背景保留各自数据。')),id==='region'&&h('details',{className:'control-group',open:true},h('summary',null,'地图描边'),color('地图描边颜色','mapStrokeColor'),range('地图描边粗细','mapStrokeWidth',0,5),range('地图描边不透明度','mapStrokeOpacity',0,100,'%'),control(['s','地图描边线型','mapStrokeType',[['solid','实线'],['dashed','虚线'],['dotted','点线']]]),color('悬浮描边颜色','mapHoverStrokeColor'),range('悬浮描边粗细','mapHoverStrokeWidth',0,8),color('九段线颜色','mapBoundaryColor'),range('九段线描边粗细','mapBoundaryWidth',0,5),range('九段线不透明度','mapBoundaryOpacity',10,100,'%')),h('details',{className:'control-group',open:true},h('summary',null,'显示选项'),['traffic','gender','region'].includes(id)&&toggle('显示图例','legend'),id!=='region'&&toggle('显示数据标签','labels'),toggle('过渡动画','animation'))),
h('p',{className:'panel-note'},'当前编辑：'+item[1]+' / '+(mobile?'移动端':'PC 端'),h('br'),'所有样式同步到导出代码。固定悬浮预览会一并出现在图片中。'))),toast&&h('div',{className:'toast',role:'status'},toast),h('dialog',{ref:dlg,onCancel:()=>setModal(null)},h('h2',null,modal==='data'?'编辑示例数据':'复制组件代码'),h('p',{className:'hint'},modal==='data'?(id==='region'?'输入各地区原始数值，图表按全部地区合计自动换算百分比；地域名称使用完整省级名称。':'修改 JSON 数组；数值须为非负数。'):'请选择下方代码手动复制。'),h('textarea',{'aria-label':'JSON 或代码',value:draft,onChange:e=>setDraft(e.target.value),readOnly:modal!=='data'}),error&&h('p',{style:{color:chartToken(c,'MapCriticalTip')}},error),h('div',{className:'actions'},h('button',{onClick:close},'取消'),modal==='data'&&h('button',{className:'primary',onClick:()=>{try{const d=validateData(JSON.parse(draft),id);setSaved(s=>({...s,data:{...s.data,[dataKey]:d.map(x=>({name:x.name,value:x.value}))}}));close();tell('示例数据已更新')}catch(e){console.error(e);setError(e.message)}}},'应用数据'))));}
ReactDOM.createRoot(document.getElementById('root')).render(h(App));
